/*
 Navicat Premium Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 100133
 Source Host           : localhost:3306
 Source Schema         : marketing

 Target Server Type    : MySQL
 Target Server Version : 100133
 File Encoding         : 65001

 Date: 14/05/2019 16:48:07
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for cache
-- ----------------------------
DROP TABLE IF EXISTS `cache`;
CREATE TABLE `cache`  (
  `key` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int(11) NOT NULL,
  UNIQUE INDEX `cache_key_unique`(`key`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for categories
-- ----------------------------
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories`  (
  `idcategory` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `namecat` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idcattype` int(11) NULL DEFAULT NULL,
  `idparent` int(11) NULL DEFAULT NULL,
  `slug` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `guid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `created_at` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0),
  PRIMARY KEY (`idcategory`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of categories
-- ----------------------------
INSERT INTO `categories` VALUES (1, 'promotion-reg', 1, NULL, NULL, NULL, '2019-04-17 08:49:08', '2019-04-17 08:49:08');
INSERT INTO `categories` VALUES (2, 'localhost', 2, NULL, NULL, NULL, '2019-04-17 08:50:18', '2019-04-17 08:50:18');
INSERT INTO `categories` VALUES (3, 'thammyvienthienkhue.vn', 2, NULL, NULL, NULL, '2019-04-17 10:35:14', '2019-04-17 10:35:14');
INSERT INTO `categories` VALUES (4, 'Tương tác', 3, NULL, NULL, NULL, '2019-04-17 11:43:13', '2019-04-17 11:43:13');

-- ----------------------------
-- Table structure for category_types
-- ----------------------------
DROP TABLE IF EXISTS `category_types`;
CREATE TABLE `category_types`  (
  `idcattype` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `catnametype` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`idcattype`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of category_types
-- ----------------------------
INSERT INTO `category_types` VALUES (1, 'post', '2019-02-27 10:36:11', '2019-02-27 10:36:11');
INSERT INTO `category_types` VALUES (2, 'website', '2019-02-27 10:53:53', '2019-02-27 10:53:53');
INSERT INTO `category_types` VALUES (3, 'interact', '2019-04-13 08:40:17', '2019-04-13 08:40:17');

-- ----------------------------
-- Table structure for depart_employees
-- ----------------------------
DROP TABLE IF EXISTS `depart_employees`;
CREATE TABLE `depart_employees`  (
  `iddepart_employee` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `iduser` int(11) NOT NULL,
  `iddepart` int(11) NOT NULL,
  `created_at` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0),
  PRIMARY KEY (`iddepart_employee`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of depart_employees
-- ----------------------------
INSERT INTO `depart_employees` VALUES (1, 2, 2, '2019-02-27 10:14:16', '2019-02-27 10:14:16');
INSERT INTO `depart_employees` VALUES (2, 3, 3, '2019-05-05 21:38:59', '2019-05-05 21:38:59');
INSERT INTO `depart_employees` VALUES (7, 12, 3, '2019-05-07 22:47:21', '2019-05-07 22:47:21');
INSERT INTO `depart_employees` VALUES (8, 13, 3, '2019-05-08 22:05:35', '2019-05-08 22:05:35');
INSERT INTO `depart_employees` VALUES (9, 14, 3, '2019-05-08 22:11:57', '2019-05-08 22:11:57');
INSERT INTO `depart_employees` VALUES (10, 15, 3, '2019-05-08 22:13:47', '2019-05-08 22:13:47');

-- ----------------------------
-- Table structure for departments
-- ----------------------------
DROP TABLE IF EXISTS `departments`;
CREATE TABLE `departments`  (
  `iddepart` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `namedepart` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idparent` int(11) NULL DEFAULT NULL,
  `created_at` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0),
  PRIMARY KEY (`iddepart`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of departments
-- ----------------------------
INSERT INTO `departments` VALUES (1, 'Marketing', NULL, '2019-02-27 09:15:12', '2019-02-27 09:15:12');
INSERT INTO `departments` VALUES (2, 'IT', 1, '2019-02-27 09:15:25', '2019-02-27 09:15:25');
INSERT INTO `departments` VALUES (3, 'CSKH', 1, '2019-05-05 21:37:58', '2019-05-05 21:37:58');

-- ----------------------------
-- Table structure for exp_products
-- ----------------------------
DROP TABLE IF EXISTS `exp_products`;
CREATE TABLE `exp_products`  (
  `idexp` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `idproduct` bigint(20) NOT NULL,
  `idcustomer` int(11) NOT NULL,
  `idemp` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `note` int(11) NOT NULL,
  `idagency` int(11) NOT NULL,
  `idtypeimp` int(11) NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`idexp`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for expposts
-- ----------------------------
DROP TABLE IF EXISTS `expposts`;
CREATE TABLE `expposts`  (
  `idexppost` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `idpost` bigint(20) NULL DEFAULT NULL,
  `id_status_type` int(11) NULL DEFAULT NULL,
  `iduser_exp` int(11) NULL DEFAULT NULL,
  `idemployee` int(11) NULL DEFAULT NULL,
  `address_reg` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `percent_process` decimal(8, 2) NULL DEFAULT NULL,
  `parent_idpost_exp` int(11) NULL DEFAULT NULL,
  `created_at` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0),
  PRIMARY KEY (`idexppost`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 51 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of expposts
-- ----------------------------
INSERT INTO `expposts` VALUES (9, 40, 2, NULL, 2, NULL, NULL, 31, '2019-04-19 16:00:14', '2019-04-19 16:00:14');
INSERT INTO `expposts` VALUES (10, 42, 2, NULL, 2, NULL, NULL, 41, '2019-04-22 14:15:47', '2019-04-22 14:15:47');
INSERT INTO `expposts` VALUES (11, 50, 2, NULL, 2, NULL, NULL, 47, '2019-04-24 12:03:12', '2019-04-24 12:03:12');
INSERT INTO `expposts` VALUES (12, 51, 2, NULL, 2, NULL, NULL, 49, '2019-04-24 16:19:47', '2019-04-24 16:19:47');
INSERT INTO `expposts` VALUES (13, 52, 2, NULL, 2, NULL, NULL, 41, '2019-04-24 17:14:38', '2019-04-24 17:14:38');
INSERT INTO `expposts` VALUES (14, 53, NULL, NULL, 2, NULL, NULL, NULL, '2019-04-30 22:55:12', '2019-04-30 22:55:12');
INSERT INTO `expposts` VALUES (15, 54, NULL, NULL, 2, NULL, NULL, NULL, '2019-04-30 23:01:52', '2019-04-30 23:01:52');
INSERT INTO `expposts` VALUES (16, 55, NULL, NULL, 2, NULL, NULL, NULL, '2019-04-30 23:02:07', '2019-04-30 23:02:07');
INSERT INTO `expposts` VALUES (17, 56, NULL, NULL, 2, NULL, NULL, 47, '2019-04-30 23:04:01', '2019-04-30 23:04:01');
INSERT INTO `expposts` VALUES (18, 57, NULL, NULL, 2, NULL, NULL, 49, '2019-04-30 23:07:24', '2019-04-30 23:07:24');
INSERT INTO `expposts` VALUES (19, 58, NULL, NULL, 2, NULL, NULL, NULL, '2019-04-30 23:09:37', '2019-04-30 23:09:37');
INSERT INTO `expposts` VALUES (20, 59, NULL, NULL, 2, NULL, NULL, NULL, '2019-04-30 23:18:23', '2019-04-30 23:18:23');
INSERT INTO `expposts` VALUES (21, 60, NULL, NULL, 2, NULL, NULL, NULL, '2019-04-30 23:19:25', '2019-04-30 23:19:25');
INSERT INTO `expposts` VALUES (22, 61, NULL, NULL, 2, NULL, NULL, NULL, '2019-04-30 23:23:56', '2019-04-30 23:23:56');
INSERT INTO `expposts` VALUES (23, 62, NULL, NULL, 2, NULL, NULL, 49, '2019-04-30 23:25:12', '2019-04-30 23:25:12');
INSERT INTO `expposts` VALUES (24, 63, NULL, NULL, 2, NULL, NULL, 49, '2019-04-30 23:27:55', '2019-04-30 23:27:55');
INSERT INTO `expposts` VALUES (25, 64, NULL, NULL, 2, NULL, NULL, 49, '2019-04-30 23:30:04', '2019-04-30 23:30:04');
INSERT INTO `expposts` VALUES (26, 65, NULL, NULL, 2, NULL, NULL, 49, '2019-04-30 23:30:42', '2019-04-30 23:30:42');
INSERT INTO `expposts` VALUES (27, 66, NULL, NULL, 2, NULL, NULL, NULL, '2019-04-30 23:31:45', '2019-04-30 23:31:45');
INSERT INTO `expposts` VALUES (28, 67, NULL, NULL, 2, NULL, NULL, 49, '2019-05-01 17:37:55', '2019-05-01 17:37:55');
INSERT INTO `expposts` VALUES (29, 68, NULL, NULL, 2, NULL, NULL, 49, '2019-05-01 17:38:24', '2019-05-01 17:38:24');
INSERT INTO `expposts` VALUES (30, 69, NULL, NULL, 2, NULL, NULL, 31, '2019-05-01 18:08:40', '2019-05-01 18:08:40');
INSERT INTO `expposts` VALUES (31, 70, NULL, NULL, 2, NULL, NULL, 31, '2019-05-01 18:19:24', '2019-05-01 18:19:24');
INSERT INTO `expposts` VALUES (32, 71, NULL, NULL, 2, NULL, NULL, 31, '2019-05-01 18:23:36', '2019-05-01 18:23:36');
INSERT INTO `expposts` VALUES (33, 72, NULL, NULL, 2, NULL, NULL, 41, '2019-05-01 18:36:07', '2019-05-01 18:36:07');
INSERT INTO `expposts` VALUES (34, 73, NULL, NULL, 2, NULL, NULL, 31, '2019-05-01 21:11:04', '2019-05-01 21:11:04');
INSERT INTO `expposts` VALUES (35, 74, NULL, NULL, 2, NULL, NULL, 41, '2019-05-01 21:17:46', '2019-05-01 21:17:46');
INSERT INTO `expposts` VALUES (36, 75, NULL, NULL, 2, NULL, NULL, 31, '2019-05-01 21:23:30', '2019-05-01 21:23:30');
INSERT INTO `expposts` VALUES (37, 76, NULL, NULL, 2, NULL, NULL, 41, '2019-05-01 21:24:28', '2019-05-01 21:24:28');
INSERT INTO `expposts` VALUES (38, 77, NULL, NULL, 2, NULL, NULL, 41, '2019-05-01 21:25:03', '2019-05-01 21:25:03');
INSERT INTO `expposts` VALUES (39, 78, NULL, NULL, 2, NULL, NULL, 41, '2019-05-01 21:33:05', '2019-05-01 21:33:05');
INSERT INTO `expposts` VALUES (40, 79, NULL, NULL, 2, NULL, NULL, 24, '2019-05-01 21:45:39', '2019-05-01 21:45:39');
INSERT INTO `expposts` VALUES (41, 80, NULL, NULL, 2, NULL, NULL, 26, '2019-05-01 22:00:23', '2019-05-01 22:00:23');
INSERT INTO `expposts` VALUES (42, 81, NULL, NULL, 2, NULL, NULL, 26, '2019-05-01 22:00:48', '2019-05-01 22:00:48');
INSERT INTO `expposts` VALUES (43, 82, NULL, NULL, 2, NULL, NULL, 26, '2019-05-01 22:04:26', '2019-05-01 22:04:26');
INSERT INTO `expposts` VALUES (44, 83, NULL, NULL, 2, NULL, NULL, 25, '2019-05-01 22:37:34', '2019-05-01 22:37:34');
INSERT INTO `expposts` VALUES (45, 84, NULL, NULL, 2, NULL, NULL, 25, '2019-05-01 22:38:12', '2019-05-01 22:38:12');
INSERT INTO `expposts` VALUES (46, 85, NULL, NULL, 2, NULL, NULL, 25, '2019-05-03 20:02:04', '2019-05-03 20:02:04');
INSERT INTO `expposts` VALUES (47, 86, NULL, NULL, 2, NULL, NULL, 25, '2019-05-03 20:03:01', '2019-05-03 20:03:01');
INSERT INTO `expposts` VALUES (48, 87, NULL, NULL, 2, NULL, NULL, 25, '2019-05-03 20:20:47', '2019-05-03 20:20:47');
INSERT INTO `expposts` VALUES (49, 88, NULL, NULL, 2, NULL, NULL, 45, '2019-05-03 20:26:43', '2019-05-03 20:26:43');
INSERT INTO `expposts` VALUES (50, 89, NULL, NULL, 2, NULL, NULL, 31, '2019-05-04 18:11:27', '2019-05-04 18:11:27');

-- ----------------------------
-- Table structure for files
-- ----------------------------
DROP TABLE IF EXISTS `files`;
CREATE TABLE `files`  (
  `idfile` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `urlfile` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_origin` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `namefile` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `typefile` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0),
  PRIMARY KEY (`idfile`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 59 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of files
-- ----------------------------
INSERT INTO `files` VALUES (1, 'uploads/2019/04/08/', 'donggia199k.jpg', '20190408_1554718711_5cab1ff7a1013.png', 'png', '2019-04-08 17:18:31', '2019-04-08 17:18:31');
INSERT INTO `files` VALUES (2, 'uploads/2019/04/09/', 'image.png', '20190409_1554772216_5cabf0f80487f.png', 'png', '2019-04-09 08:10:16', '2019-04-09 08:10:16');
INSERT INTO `files` VALUES (3, 'uploads/2019/04/10/', 'donggia199k.jpg', '20190410_1554858419_5cad41b32c97f.png', 'png', '2019-04-10 08:06:59', '2019-04-10 08:06:59');
INSERT INTO `files` VALUES (4, 'uploads/2019/05/10/20190510_1557479855_5cd541af9efee.png', '', '20190510_1557479855_5cd541af9efee.png', 'png', '2019-05-10 16:17:35', '2019-05-10 16:17:35');
INSERT INTO `files` VALUES (5, 'uploads/2019/05/10/20190510_1557479906_5cd541e266025.png', '', '20190510_1557479906_5cd541e266025.png', 'png', '2019-05-10 16:18:26', '2019-05-10 16:18:26');
INSERT INTO `files` VALUES (6, 'uploads/2019/05/11/20190511_1557538617_5cd627393d527.png', '', '20190511_1557538617_5cd627393d527.png', 'png', '2019-05-11 08:36:57', '2019-05-11 08:36:57');
INSERT INTO `files` VALUES (7, 'uploads/2019/05/11/20190511_1557541962_5cd6344a2c218.png', '', '20190511_1557541962_5cd6344a2c218.png', 'png', '2019-05-11 09:32:42', '2019-05-11 09:32:42');
INSERT INTO `files` VALUES (8, 'uploads/2019/05/13/20190513_1557709794_5cd8c3e285e49.png', '', '20190513_1557709794_5cd8c3e285e49.png', 'png', '2019-05-13 08:09:54', '2019-05-13 08:09:54');
INSERT INTO `files` VALUES (9, 'uploads/2019/05/13/', 'a-thanh.png', '20190513_1557735316_5cd927947a2cb.png', 'png', '2019-05-13 15:15:16', '2019-05-13 15:15:16');
INSERT INTO `files` VALUES (10, 'uploads/2019/05/13/', 'chon-k18-a.jpg1000.jpg', '20190513_1557736309_5cd92b75091c6.png', 'png', '2019-05-13 15:31:49', '2019-05-13 15:31:49');
INSERT INTO `files` VALUES (11, 'uploads/2019/05/14/20190514_1557818813_5cda6dbd0c8d4.png', '', '20190514_1557818813_5cda6dbd0c8d4.png', 'png', '2019-05-14 14:26:53', '2019-05-14 14:26:53');
INSERT INTO `files` VALUES (12, 'uploads/2019/05/14/20190514_1557818958_5cda6e4eca7ee.png', '', '20190514_1557818958_5cda6e4eca7ee.png', 'png', '2019-05-14 14:29:18', '2019-05-14 14:29:18');
INSERT INTO `files` VALUES (13, 'uploads/2019/05/14/20190514_1557819093_5cda6ed564ab5.png', '', '20190514_1557819093_5cda6ed564ab5.png', 'png', '2019-05-14 14:31:33', '2019-05-14 14:31:33');
INSERT INTO `files` VALUES (14, 'uploads/2019/05/14/20190514_1557819233_5cda6f61b81bd.png', '', '20190514_1557819233_5cda6f61b81bd.png', 'png', '2019-05-14 14:33:53', '2019-05-14 14:33:53');
INSERT INTO `files` VALUES (15, 'uploads/2019/05/14/20190514_1557819233_5cda6f61e0643.png', '', '20190514_1557819233_5cda6f61e0643.png', 'png', '2019-05-14 14:33:53', '2019-05-14 14:33:53');
INSERT INTO `files` VALUES (16, 'uploads/2019/05/14/20190514_1557819233_5cda6f61e78e0.png', '', '20190514_1557819233_5cda6f61e78e0.png', 'png', '2019-05-14 14:33:53', '2019-05-14 14:33:53');
INSERT INTO `files` VALUES (17, 'uploads/2019/05/14/20190514_1557819400_5cda7008531ba.png', '', '20190514_1557819400_5cda7008531ba.png', 'png', '2019-05-14 14:36:40', '2019-05-14 14:36:40');
INSERT INTO `files` VALUES (18, 'uploads/2019/05/14/20190514_1557819400_5cda70086ba2d.png', '', '20190514_1557819400_5cda70086ba2d.png', 'png', '2019-05-14 14:36:40', '2019-05-14 14:36:40');
INSERT INTO `files` VALUES (19, 'uploads/2019/05/14/20190514_1557819400_5cda70087290a.png', '', '20190514_1557819400_5cda70087290a.png', 'png', '2019-05-14 14:36:40', '2019-05-14 14:36:40');
INSERT INTO `files` VALUES (20, 'uploads/2019/05/14/20190514_1557820118_5cda72d6894f8.png', '', '20190514_1557820118_5cda72d6894f8.png', 'png', '2019-05-14 14:48:38', '2019-05-14 14:48:38');
INSERT INTO `files` VALUES (21, 'uploads/2019/05/14/20190514_1557820118_5cda72d69415b.png', '', '20190514_1557820118_5cda72d69415b.png', 'png', '2019-05-14 14:48:38', '2019-05-14 14:48:38');
INSERT INTO `files` VALUES (22, 'uploads/2019/05/14/20190514_1557820118_5cda72d69d4ae.png', '', '20190514_1557820118_5cda72d69d4ae.png', 'png', '2019-05-14 14:48:38', '2019-05-14 14:48:38');
INSERT INTO `files` VALUES (23, 'uploads/2019/05/14/20190514_1557820356_5cda73c4b0dbd.png', '', '20190514_1557820356_5cda73c4b0dbd.png', 'png', '2019-05-14 14:52:36', '2019-05-14 14:52:36');
INSERT INTO `files` VALUES (24, 'uploads/2019/05/14/20190514_1557820356_5cda73c4c048c.png', '', '20190514_1557820356_5cda73c4c048c.png', 'png', '2019-05-14 14:52:36', '2019-05-14 14:52:36');
INSERT INTO `files` VALUES (25, 'uploads/2019/05/14/20190514_1557820356_5cda73c4d57b4.png', '', '20190514_1557820356_5cda73c4d57b4.png', 'png', '2019-05-14 14:52:36', '2019-05-14 14:52:36');
INSERT INTO `files` VALUES (26, 'uploads/2019/05/14/20190514_1557820866_5cda75c2434e0.png', '', '20190514_1557820866_5cda75c2434e0.png', 'png', '2019-05-14 15:01:06', '2019-05-14 15:01:06');
INSERT INTO `files` VALUES (27, 'uploads/2019/05/14/20190514_1557820866_5cda75c24ca7e.png', '', '20190514_1557820866_5cda75c24ca7e.png', 'png', '2019-05-14 15:01:06', '2019-05-14 15:01:06');
INSERT INTO `files` VALUES (28, 'uploads/2019/05/14/20190514_1557820866_5cda75c256bfc.png', '', '20190514_1557820866_5cda75c256bfc.png', 'png', '2019-05-14 15:01:06', '2019-05-14 15:01:06');
INSERT INTO `files` VALUES (29, 'uploads/2019/05/14/20190514_1557821777_5cda7951958fd.png', '', '20190514_1557821777_5cda7951958fd.png', 'png', '2019-05-14 15:16:17', '2019-05-14 15:16:17');
INSERT INTO `files` VALUES (30, 'uploads/2019/05/14/20190514_1557821777_5cda7951a0368.png', '', '20190514_1557821777_5cda7951a0368.png', 'png', '2019-05-14 15:16:17', '2019-05-14 15:16:17');
INSERT INTO `files` VALUES (31, 'uploads/2019/05/14/20190514_1557821777_5cda7951aba7a.png', '', '20190514_1557821777_5cda7951aba7a.png', 'png', '2019-05-14 15:16:17', '2019-05-14 15:16:17');
INSERT INTO `files` VALUES (32, 'uploads/2019/05/14/20190514_1557822215_5cda7b0737af4.png', '', '20190514_1557822215_5cda7b0737af4.png', 'png', '2019-05-14 15:23:35', '2019-05-14 15:23:35');
INSERT INTO `files` VALUES (33, 'uploads/2019/05/14/20190514_1557822215_5cda7b0742668.png', '', '20190514_1557822215_5cda7b0742668.png', 'png', '2019-05-14 15:23:35', '2019-05-14 15:23:35');
INSERT INTO `files` VALUES (34, 'uploads/2019/05/14/20190514_1557822215_5cda7b074fe87.png', '', '20190514_1557822215_5cda7b074fe87.png', 'png', '2019-05-14 15:23:35', '2019-05-14 15:23:35');
INSERT INTO `files` VALUES (35, 'uploads/2019/05/14/20190514_1557822479_5cda7c0fe8c04.png', '', '20190514_1557822479_5cda7c0fe8c04.png', 'png', '2019-05-14 15:27:59', '2019-05-14 15:27:59');
INSERT INTO `files` VALUES (36, 'uploads/2019/05/14/20190514_1557822480_5cda7c1001d12.png', '', '20190514_1557822480_5cda7c1001d12.png', 'png', '2019-05-14 15:28:00', '2019-05-14 15:28:00');
INSERT INTO `files` VALUES (37, 'uploads/2019/05/14/20190514_1557822480_5cda7c100781a.png', '', '20190514_1557822480_5cda7c100781a.png', 'png', '2019-05-14 15:28:00', '2019-05-14 15:28:00');
INSERT INTO `files` VALUES (38, 'uploads/2019/05/14/20190514_1557823309_5cda7f4de846e.png', '', '20190514_1557823309_5cda7f4de846e.png', 'png', '2019-05-14 15:41:49', '2019-05-14 15:41:49');
INSERT INTO `files` VALUES (39, 'uploads/2019/05/14/20190514_1557823310_5cda7f4e022f8.png', '', '20190514_1557823310_5cda7f4e022f8.png', 'png', '2019-05-14 15:41:50', '2019-05-14 15:41:50');
INSERT INTO `files` VALUES (40, 'uploads/2019/05/14/20190514_1557823310_5cda7f4e0e54f.png', '', '20190514_1557823310_5cda7f4e0e54f.png', 'png', '2019-05-14 15:41:50', '2019-05-14 15:41:50');
INSERT INTO `files` VALUES (41, 'uploads/2019/05/14/20190514_1557823573_5cda8055c4dca.png', '', '20190514_1557823573_5cda8055c4dca.png', 'png', '2019-05-14 15:46:13', '2019-05-14 15:46:13');
INSERT INTO `files` VALUES (42, 'uploads/2019/05/14/20190514_1557823573_5cda8055d4757.png', '', '20190514_1557823573_5cda8055d4757.png', 'png', '2019-05-14 15:46:13', '2019-05-14 15:46:13');
INSERT INTO `files` VALUES (43, 'uploads/2019/05/14/20190514_1557823573_5cda8055dee26.png', '', '20190514_1557823573_5cda8055dee26.png', 'png', '2019-05-14 15:46:13', '2019-05-14 15:46:13');
INSERT INTO `files` VALUES (44, 'uploads/2019/05/14/20190514_1557823698_5cda80d2bfe16.png', '', '20190514_1557823698_5cda80d2bfe16.png', 'png', '2019-05-14 15:48:18', '2019-05-14 15:48:18');
INSERT INTO `files` VALUES (45, 'uploads/2019/05/14/20190514_1557823698_5cda80d2cc87d.png', '', '20190514_1557823698_5cda80d2cc87d.png', 'png', '2019-05-14 15:48:18', '2019-05-14 15:48:18');
INSERT INTO `files` VALUES (46, 'uploads/2019/05/14/20190514_1557823698_5cda80d2d8277.png', '', '20190514_1557823698_5cda80d2d8277.png', 'png', '2019-05-14 15:48:18', '2019-05-14 15:48:18');
INSERT INTO `files` VALUES (47, 'uploads/2019/05/14/20190514_1557823831_5cda8157486a6.png', '', '20190514_1557823831_5cda8157486a6.png', 'png', '2019-05-14 15:50:31', '2019-05-14 15:50:31');
INSERT INTO `files` VALUES (48, 'uploads/2019/05/14/20190514_1557823831_5cda815753f7c.png', '', '20190514_1557823831_5cda815753f7c.png', 'png', '2019-05-14 15:50:31', '2019-05-14 15:50:31');
INSERT INTO `files` VALUES (49, 'uploads/2019/05/14/20190514_1557823831_5cda815759a1c.png', '', '20190514_1557823831_5cda815759a1c.png', 'png', '2019-05-14 15:50:31', '2019-05-14 15:50:31');
INSERT INTO `files` VALUES (50, 'uploads/2019/05/14/20190514_1557825542_5cda8806bf810.png', '', '20190514_1557825542_5cda8806bf810.png', 'png', '2019-05-14 16:19:02', '2019-05-14 16:19:02');
INSERT INTO `files` VALUES (51, 'uploads/2019/05/14/20190514_1557825542_5cda8806c8565.png', '', '20190514_1557825542_5cda8806c8565.png', 'png', '2019-05-14 16:19:02', '2019-05-14 16:19:02');
INSERT INTO `files` VALUES (52, 'uploads/2019/05/14/20190514_1557825542_5cda8806d0a1e.png', '', '20190514_1557825542_5cda8806d0a1e.png', 'png', '2019-05-14 16:19:02', '2019-05-14 16:19:02');
INSERT INTO `files` VALUES (53, 'uploads/2019/05/14/20190514_1557825884_5cda895ccb1e5.png', '', '20190514_1557825884_5cda895ccb1e5.png', 'png', '2019-05-14 16:24:44', '2019-05-14 16:24:44');
INSERT INTO `files` VALUES (54, 'uploads/2019/05/14/20190514_1557825884_5cda895cee923.png', '', '20190514_1557825884_5cda895cee923.png', 'png', '2019-05-14 16:24:44', '2019-05-14 16:24:44');
INSERT INTO `files` VALUES (55, 'uploads/2019/05/14/20190514_1557825885_5cda895d06bd7.png', '', '20190514_1557825885_5cda895d06bd7.png', 'png', '2019-05-14 16:24:45', '2019-05-14 16:24:45');
INSERT INTO `files` VALUES (56, 'uploads/2019/05/14/20190514_1557826194_5cda8a92337be.png', '', '20190514_1557826194_5cda8a92337be.png', 'png', '2019-05-14 16:29:54', '2019-05-14 16:29:54');
INSERT INTO `files` VALUES (57, 'uploads/2019/05/14/20190514_1557826194_5cda8a923eaa3.png', '', '20190514_1557826194_5cda8a923eaa3.png', 'png', '2019-05-14 16:29:54', '2019-05-14 16:29:54');
INSERT INTO `files` VALUES (58, 'uploads/2019/05/14/20190514_1557826194_5cda8a924697b.png', '', '20190514_1557826194_5cda8a924697b.png', 'png', '2019-05-14 16:29:54', '2019-05-14 16:29:54');

-- ----------------------------
-- Table structure for grants
-- ----------------------------
DROP TABLE IF EXISTS `grants`;
CREATE TABLE `grants`  (
  `idgrant` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `idrole` int(11) NOT NULL,
  `to_iduser` int(11) NOT NULL,
  `by_iduser` int(11) NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`idgrant`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of grants
-- ----------------------------
INSERT INTO `grants` VALUES (1, 1, 2, 2, '2019-04-13 08:30:20', '2019-04-13 08:30:20');

-- ----------------------------
-- Table structure for imp_perms
-- ----------------------------
DROP TABLE IF EXISTS `imp_perms`;
CREATE TABLE `imp_perms`  (
  `idimp_perm` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `idperm` int(11) NOT NULL,
  `idrole` int(11) NOT NULL,
  `iduserimp` int(11) NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`idimp_perm`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of imp_perms
-- ----------------------------
INSERT INTO `imp_perms` VALUES (1, 1, 1, 2, '2019-04-13 08:30:03', '2019-04-13 08:30:03');

-- ----------------------------
-- Table structure for imp_products
-- ----------------------------
DROP TABLE IF EXISTS `imp_products`;
CREATE TABLE `imp_products`  (
  `idimp` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `idproduct` bigint(20) NOT NULL,
  `idcustomer` int(11) NOT NULL,
  `idemp` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `note` int(11) NOT NULL,
  `idagency` int(11) NOT NULL,
  `idtypeimp` int(11) NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`idimp`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for impposts
-- ----------------------------
DROP TABLE IF EXISTS `impposts`;
CREATE TABLE `impposts`  (
  `idimppost` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `idpost` bigint(20) NULL DEFAULT NULL,
  `id_status_type` int(11) NULL DEFAULT NULL,
  `percent_process` decimal(8, 2) NULL DEFAULT NULL,
  `iduser_imp` int(11) NULL DEFAULT NULL,
  `idemployee` int(11) NULL DEFAULT NULL,
  `address_reg` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `parent_idpost_imp` int(11) NULL DEFAULT NULL,
  `created_at` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0),
  PRIMARY KEY (`idimppost`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 27 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of impposts
-- ----------------------------
INSERT INTO `impposts` VALUES (1, 24, 1, 0.00, 26, NULL, 'Bình Dương', NULL, '2019-04-17 08:50:18', '2019-04-17 08:50:18');
INSERT INTO `impposts` VALUES (2, 25, 1, 0.00, 27, NULL, 'Bình Dương', NULL, '2019-04-17 09:12:53', '2019-04-17 09:12:53');
INSERT INTO `impposts` VALUES (3, 26, 1, 0.00, 28, NULL, 'Bình Dương', NULL, '2019-04-17 10:35:14', '2019-04-29 10:34:20');
INSERT INTO `impposts` VALUES (4, 27, 1, 0.00, 29, NULL, 'Bình Dương', NULL, '2019-04-17 10:43:39', '2019-04-17 10:43:39');
INSERT INTO `impposts` VALUES (5, 28, 1, 0.00, 30, NULL, 'binh duong', NULL, '2019-04-17 10:51:55', '2019-04-17 10:51:55');
INSERT INTO `impposts` VALUES (6, 29, 1, 0.00, 31, NULL, 'Bình Dương', NULL, '2019-04-18 08:34:13', '2019-04-18 08:34:13');
INSERT INTO `impposts` VALUES (7, 30, 1, 0.00, 32, NULL, 'Bình Dương', NULL, '2019-04-18 10:07:14', '2019-04-18 10:07:14');
INSERT INTO `impposts` VALUES (8, 31, 1, 0.00, 33, NULL, 'Bình Dương', NULL, '2019-04-19 15:16:24', '2019-04-19 15:16:24');
INSERT INTO `impposts` VALUES (9, 41, 1, 0.00, 26, NULL, 'Bình Dương', NULL, '2019-04-22 11:29:39', '2019-04-22 11:29:39');
INSERT INTO `impposts` VALUES (10, 45, 1, 0.00, 26, NULL, 'Sài Gòn', NULL, '2019-04-23 15:43:46', '2019-04-23 15:43:46');
INSERT INTO `impposts` VALUES (11, 46, 1, 0.00, 34, NULL, 'Bình Dương', NULL, '2019-04-23 16:54:45', '2019-04-23 16:54:45');
INSERT INTO `impposts` VALUES (12, 47, 1, 0.00, 35, NULL, 'Bình Dương', NULL, '2019-04-24 11:58:14', '2019-04-24 11:58:14');
INSERT INTO `impposts` VALUES (13, 48, 1, 0.00, 36, NULL, 'Sài Gòn', NULL, '2019-04-24 12:01:21', '2019-04-24 12:01:21');
INSERT INTO `impposts` VALUES (14, 49, 1, 0.00, 37, NULL, 'Đồng Nai', NULL, '2019-04-24 12:01:49', '2019-04-24 12:01:49');
INSERT INTO `impposts` VALUES (15, 90, 1, 0.00, 38, NULL, 'Bình Dương', NULL, '2019-05-13 15:15:16', '2019-05-13 15:15:16');
INSERT INTO `impposts` VALUES (16, 91, 1, 0.00, 39, NULL, 'Bình Dương', NULL, '2019-05-13 15:31:49', '2019-05-13 15:31:49');
INSERT INTO `impposts` VALUES (17, 92, 1, 0.00, 40, NULL, 'thu duc', NULL, '2019-05-14 14:36:40', '2019-05-14 14:36:40');
INSERT INTO `impposts` VALUES (18, 93, 1, 0.00, 41, NULL, 'thu duc', NULL, '2019-05-14 15:01:06', '2019-05-14 15:01:06');
INSERT INTO `impposts` VALUES (19, 94, 1, 0.00, 42, NULL, 'fb', NULL, '2019-05-14 15:23:35', '2019-05-14 15:23:35');
INSERT INTO `impposts` VALUES (20, 95, 1, 0.00, 30, NULL, 'fb', NULL, '2019-05-14 15:41:50', '2019-05-14 15:41:50');
INSERT INTO `impposts` VALUES (21, 96, 1, 0.00, 43, NULL, 'thu duc', NULL, '2019-05-14 15:46:14', '2019-05-14 15:46:14');
INSERT INTO `impposts` VALUES (22, 97, 1, 0.00, 44, NULL, 'thu duc', NULL, '2019-05-14 15:48:19', '2019-05-14 15:48:19');
INSERT INTO `impposts` VALUES (23, 98, 1, 0.00, 45, NULL, 'fb', NULL, '2019-05-14 15:50:31', '2019-05-14 15:50:31');
INSERT INTO `impposts` VALUES (24, 99, 1, 0.00, 40, NULL, 'thu duc', NULL, '2019-05-14 16:19:03', '2019-05-14 16:19:03');
INSERT INTO `impposts` VALUES (25, 100, 1, 0.00, 46, NULL, 'binh thạnh', NULL, '2019-05-14 16:24:45', '2019-05-14 16:24:45');
INSERT INTO `impposts` VALUES (26, 101, 1, 0.00, 47, NULL, 'ggh', NULL, '2019-05-14 16:29:54', '2019-05-14 16:29:54');

-- ----------------------------
-- Table structure for migrations
-- ----------------------------
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 81 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of migrations
-- ----------------------------
INSERT INTO `migrations` VALUES (1, '2014_10_12_000000_create_users_table', 1);
INSERT INTO `migrations` VALUES (2, '2014_10_12_100000_create_password_resets_table', 1);
INSERT INTO `migrations` VALUES (3, '2016_06_01_000001_create_oauth_auth_codes_table', 1);
INSERT INTO `migrations` VALUES (4, '2016_06_01_000002_create_oauth_access_tokens_table', 1);
INSERT INTO `migrations` VALUES (5, '2016_06_01_000003_create_oauth_refresh_tokens_table', 1);
INSERT INTO `migrations` VALUES (6, '2016_06_01_000004_create_oauth_clients_table', 1);
INSERT INTO `migrations` VALUES (7, '2016_06_01_000005_create_oauth_personal_access_clients_table', 1);
INSERT INTO `migrations` VALUES (8, '2018_09_28_071047_create_sv_customers_table', 1);
INSERT INTO `migrations` VALUES (9, '2018_09_28_071406_create_sv_sends_table', 1);
INSERT INTO `migrations` VALUES (10, '2018_09_28_071547_create_sv_receives_table', 1);
INSERT INTO `migrations` VALUES (11, '2018_09_28_071605_create_sv_campaigns_table', 1);
INSERT INTO `migrations` VALUES (12, '2018_09_28_092221_create_sv_post_types_table', 1);
INSERT INTO `migrations` VALUES (13, '2018_10_01_070557_create_sv_posts_table', 1);
INSERT INTO `migrations` VALUES (14, '2018_10_28_070541_create_products_table', 1);
INSERT INTO `migrations` VALUES (15, '2018_10_28_070821_create_imp_products_table', 1);
INSERT INTO `migrations` VALUES (16, '2018_10_28_070834_create_exp_products_table', 1);
INSERT INTO `migrations` VALUES (17, '2018_11_29_134641_create_permissions_table', 1);
INSERT INTO `migrations` VALUES (18, '2018_11_29_135338_create_roles_table', 1);
INSERT INTO `migrations` VALUES (19, '2018_11_29_135505_create_imp_perms_table', 1);
INSERT INTO `migrations` VALUES (20, '2018_11_29_135523_create_grants_table', 1);
INSERT INTO `migrations` VALUES (21, '2018_12_14_132905_listgrantbyid_procedure', 1);
INSERT INTO `migrations` VALUES (22, '2018_12_15_032820_listpost_procedure', 1);
INSERT INTO `migrations` VALUES (23, '2018_12_16_102228_create_post_types_table', 1);
INSERT INTO `migrations` VALUES (24, '2018_12_16_125347_create_category_types_table', 1);
INSERT INTO `migrations` VALUES (25, '2018_12_18_081612_listcatparent_procedure', 1);
INSERT INTO `migrations` VALUES (26, '2018_12_18_094626_sellistcategorybyid_procedure', 1);
INSERT INTO `migrations` VALUES (27, '2018_12_20_042704_create_status_types_table', 1);
INSERT INTO `migrations` VALUES (28, '2018_12_23_092920_update_imppost_by_id_procedure', 1);
INSERT INTO `migrations` VALUES (29, '2019_01_03_084802_creat_files_table', 1);
INSERT INTO `migrations` VALUES (30, '2019_01_03_085744_insert_files_procedure', 1);
INSERT INTO `migrations` VALUES (31, '2019_01_06_144658_sel_department_by_id_procedure', 1);
INSERT INTO `migrations` VALUES (32, '2019_01_06_174759_create_depart_employees_table', 1);
INSERT INTO `migrations` VALUES (33, '2019_01_06_175900_create_profiles_table', 1);
INSERT INTO `migrations` VALUES (34, '2019_01_06_204904_list_depart_parent_procedure', 1);
INSERT INTO `migrations` VALUES (35, '2019_01_06_212731_sel_list_department_by_id_procedure', 1);
INSERT INTO `migrations` VALUES (36, '2019_01_06_223105_list_department_procedure', 1);
INSERT INTO `migrations` VALUES (37, '2019_01_06_225258_create_departments_table', 1);
INSERT INTO `migrations` VALUES (38, '2019_01_08_233801_list_sel_emp_depart_procedure', 1);
INSERT INTO `migrations` VALUES (39, '2019_02_11_091036_create_post_has_files_table', 1);
INSERT INTO `migrations` VALUES (40, '2019_02_11_095450_create_posts_table', 1);
INSERT INTO `migrations` VALUES (41, '2019_02_11_100541_post_has_file_procedure', 1);
INSERT INTO `migrations` VALUES (42, '2019_02_11_114745_list_type_selected_procedure', 1);
INSERT INTO `migrations` VALUES (43, '2019_02_11_154503_getparentidprocedure', 1);
INSERT INTO `migrations` VALUES (44, '2019_02_11_172247_post_by_id_procedure', 1);
INSERT INTO `migrations` VALUES (45, '2019_02_11_231226_create_impposts_table', 1);
INSERT INTO `migrations` VALUES (46, '2019_02_11_231546_create_expposts_table', 1);
INSERT INTO `migrations` VALUES (47, '2019_02_12_042124_create_categories_table', 1);
INSERT INTO `migrations` VALUES (48, '2019_02_12_044223_list_category_procedure', 1);
INSERT INTO `migrations` VALUES (49, '2019_02_12_234640_sel_categoryby_id_procedure', 1);
INSERT INTO `migrations` VALUES (50, '2019_02_13_000954_insert_post_procedure', 1);
INSERT INTO `migrations` VALUES (51, '2019_02_17_142125_list_impperm_procedure', 1);
INSERT INTO `migrations` VALUES (52, '2019_02_17_142536_imppermbyid_procedure', 1);
INSERT INTO `migrations` VALUES (53, '2019_02_17_142814_listgrant_procedure', 1);
INSERT INTO `migrations` VALUES (57, '2019_02_26_222724_list_role_idperm_procedure', 2);
INSERT INTO `migrations` VALUES (58, '2019_02_28_153458_create_post_has_file_table', 2);
INSERT INTO `migrations` VALUES (59, '2019_02_28_171709_creat_post_api_procedure', 3);
INSERT INTO `migrations` VALUES (60, '2019_03_01_234312_creat_api_post_procedure', 4);
INSERT INTO `migrations` VALUES (61, '2019_04_09_173504_filter_user_reg', 5);
INSERT INTO `migrations` VALUES (62, '2019_04_11_085120_customer_reg_procedure', 6);
INSERT INTO `migrations` VALUES (63, '2019_04_14_151243_list_all_category_procedure', 7);
INSERT INTO `migrations` VALUES (64, '2019_04_14_152226_create_post_types_table', 8);
INSERT INTO `migrations` VALUES (65, '2019_04_14_202707_creat_post_api_procedure', 9);
INSERT INTO `migrations` VALUES (66, '2019_04_14_205408_create_impposts_table', 10);
INSERT INTO `migrations` VALUES (67, '2019_04_14_220123_list_customer_register_procedure', 11);
INSERT INTO `migrations` VALUES (68, '2019_04_15_215628_create_categories_table', 12);
INSERT INTO `migrations` VALUES (69, '2019_04_16_113436_list_all_cat_by_type', 12);
INSERT INTO `migrations` VALUES (70, '2019_04_16_221907_list_post_type_procedure', 12);
INSERT INTO `migrations` VALUES (71, '2019_04_18_135716_list_status_type_procedure', 13);
INSERT INTO `migrations` VALUES (72, '2019_04_18_171344_create_expposts_table', 14);
INSERT INTO `migrations` VALUES (73, '2019_05_01_221732_create_table_profile', 15);
INSERT INTO `migrations` VALUES (74, '2019_05_07_195350_creat_profile_procedure', 16);
INSERT INTO `migrations` VALUES (75, '2019_05_08_211922_create_cache_table', 17);
INSERT INTO `migrations` VALUES (76, '2019_05_08_214108_delete_user_procedure', 17);
INSERT INTO `migrations` VALUES (77, '2019_05_08_215614_create_profile_procedure', 18);
INSERT INTO `migrations` VALUES (78, '2019_05_08_222732_select_profile_procedure', 19);
INSERT INTO `migrations` VALUES (79, '2019_05_09_163643_update_profile_procedure', 20);
INSERT INTO `migrations` VALUES (80, '2019_05_10_164806_upload_avatar_procedure', 20);

-- ----------------------------
-- Table structure for oauth_access_tokens
-- ----------------------------
DROP TABLE IF EXISTS `oauth_access_tokens`;
CREATE TABLE `oauth_access_tokens`  (
  `id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NULL DEFAULT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `scopes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  `expires_at` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `oauth_access_tokens_user_id_index`(`user_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of oauth_access_tokens
-- ----------------------------
INSERT INTO `oauth_access_tokens` VALUES ('02c5eb6246239dc8c502a00f04cd968d914088f56382271351eaa125d81d96bc05cef22fa727ac2e', 2, 1, 'MyApp', '[]', 0, '2019-02-27 15:50:47', '2019-02-27 15:50:47', '2020-02-27 15:50:47');
INSERT INTO `oauth_access_tokens` VALUES ('04efc9ed5af1655c64c2590bc9f572b32eb7eca07e429129cb9efd1baca6c0ec2e5ff66746fee23f', 2, 1, 'MyApp', '[]', 0, '2019-05-10 10:38:18', '2019-05-10 10:38:18', '2020-05-10 10:38:18');
INSERT INTO `oauth_access_tokens` VALUES ('067dac3746bfb9865589ab25f53533f9f3eed249169d635653c218b448f75bf1cac28cbb8eca3250', 2, 1, 'MyApp', '[]', 0, '2019-05-01 17:33:54', '2019-05-01 17:33:54', '2020-05-01 17:33:54');
INSERT INTO `oauth_access_tokens` VALUES ('0932576f7ac4ca702fd83f9c0d1181b2bb4ca461c52af492bcde5e1cf5fdbe3ac2170f23c2364a6f', 3, 1, 'MyApp', '[]', 0, '2019-05-05 21:38:59', '2019-05-05 21:38:59', '2020-05-05 21:38:59');
INSERT INTO `oauth_access_tokens` VALUES ('096218f4c8508b93d23381d4d757b6a898a5f7f57d775802d3c7781cb095559f9c710fcbaa7f88f2', 2, 1, 'MyApp', '[]', 0, '2019-04-26 09:06:09', '2019-04-26 09:06:09', '2020-04-26 09:06:09');
INSERT INTO `oauth_access_tokens` VALUES ('114792509f5c33ac5ae710663876d91eeea6885676508e9e22b0c6b41f1d287451383592a789d6e7', 2, 1, 'MyApp', '[]', 0, '2019-05-13 15:16:00', '2019-05-13 15:16:00', '2020-05-13 15:16:00');
INSERT INTO `oauth_access_tokens` VALUES ('11fd90efa8b1ffc1780c3899af04cc6ef25df8b30a97508a9e7aca7ee6e37dab12c2e62fe532c6a8', 2, 1, 'MyApp', '[]', 0, '2019-04-23 08:09:32', '2019-04-23 08:09:32', '2020-04-23 08:09:32');
INSERT INTO `oauth_access_tokens` VALUES ('129d09689dc82206833403e3855a89b985d6f90463516b28b3aa496509dad671adf2f9c8da040218', 2, 1, 'MyApp', '[]', 0, '2019-05-01 21:45:08', '2019-05-01 21:45:08', '2020-05-01 21:45:08');
INSERT INTO `oauth_access_tokens` VALUES ('14fadc8eb48e6f841b30759cd1619ff57deb7ffb0367940679e96a3c6b0a204ed138576e294b04d1', 2, 1, 'MyApp', '[]', 0, '2019-04-25 11:28:06', '2019-04-25 11:28:06', '2020-04-25 11:28:06');
INSERT INTO `oauth_access_tokens` VALUES ('17b21775cf6079c603283918bb55014cb927a5d2a6b997667f583498cb6301635ace8c2f39f15360', 2, 1, 'MyApp', '[]', 0, '2019-04-27 08:36:55', '2019-04-27 08:36:55', '2020-04-27 08:36:55');
INSERT INTO `oauth_access_tokens` VALUES ('1f736237bd5b2795b3fe4d67c70c259a800187d1262f7a682e12dc709b1255b8876529cce09fc6c4', 2, 1, 'MyApp', '[]', 0, '2019-04-25 15:15:20', '2019-04-25 15:15:20', '2020-04-25 15:15:20');
INSERT INTO `oauth_access_tokens` VALUES ('241b17895075f84cc18f380d036d7e5840e61f826db14c36d1397a096fc7b4782655a4b5d9f8da90', 2, 1, 'MyApp', '[]', 0, '2019-03-26 13:54:32', '2019-03-26 13:54:32', '2020-03-26 13:54:32');
INSERT INTO `oauth_access_tokens` VALUES ('28a0fcfa1ade07d20ac6da7747bbf31d7435d18a48a2110bd201ac5d337dd9b83e4d47f2b2f21a91', 2, 1, 'MyApp', '[]', 0, '2019-05-05 20:59:14', '2019-05-05 20:59:14', '2020-05-05 20:59:14');
INSERT INTO `oauth_access_tokens` VALUES ('29f32cd7e62afccec2f43fb5df42b2a7f48a38a4e0c8ea56a728d2fdaba864deea206834784167fe', 2, 1, 'MyApp', '[]', 0, '2019-02-27 10:15:01', '2019-02-27 10:15:01', '2020-02-27 10:15:01');
INSERT INTO `oauth_access_tokens` VALUES ('2d4e4f6c487aeb65d97a4c1ca61110c68d53de18a7b459c9c7b9f3ccbfa13ed883a35eb07ca4cbc9', 2, 1, 'MyApp', '[]', 0, '2019-05-14 08:05:49', '2019-05-14 08:05:49', '2020-05-14 08:05:49');
INSERT INTO `oauth_access_tokens` VALUES ('3089e07e48e983d117508033bdb4638a080f6ffa9a5ff51efb5933a2973ee32ff4196fa1c6673a73', 2, 1, 'MyApp', '[]', 0, '2019-05-10 10:02:47', '2019-05-10 10:02:47', '2020-05-10 10:02:47');
INSERT INTO `oauth_access_tokens` VALUES ('325cdc3ca68af589fe22ec144c335c3b95e833cf51dd38e8aa830a9d0f4abfe80cde9458953d9af6', 2, 1, 'MyApp', '[]', 0, '2019-05-11 08:10:02', '2019-05-11 08:10:02', '2020-05-11 08:10:02');
INSERT INTO `oauth_access_tokens` VALUES ('32b0f24fbab58f05d16edd12d80d4f010e88cb28fd104fcbc1b56e6dd7c55d7d8f396bf205f53162', 2, 1, 'MyApp', '[]', 0, '2019-04-22 08:10:07', '2019-04-22 08:10:07', '2020-04-22 08:10:07');
INSERT INTO `oauth_access_tokens` VALUES ('34a74ab1625693d9e64d772dddc35a6aad295a47c079d1b4d963726ce816393e95f3437efdc3d152', 2, 1, 'MyApp', '[]', 0, '2019-05-01 21:05:29', '2019-05-01 21:05:29', '2020-05-01 21:05:29');
INSERT INTO `oauth_access_tokens` VALUES ('3853eedd8cdad69da0d2604dd6ac6704067111d15cf4460beccd98ac39d98c40f3b24d8f8ba1fd2b', 10, 1, 'MyApp', '[]', 0, '2019-05-07 20:27:10', '2019-05-07 20:27:10', '2020-05-07 20:27:10');
INSERT INTO `oauth_access_tokens` VALUES ('3f16c297a4305998873ead59276f56653df2ad9ecf17e0c238d3fc7f726d0cfd4a5a0897fc652557', 2, 1, 'MyApp', '[]', 0, '2019-02-28 13:33:42', '2019-02-28 13:33:42', '2020-02-28 13:33:42');
INSERT INTO `oauth_access_tokens` VALUES ('43b9ed78e7c9778bfc62b2241119bd7e966de4b148a481282325daf5b666da51994c56e10a5563cc', 2, 1, 'MyApp', '[]', 0, '2019-05-03 20:00:48', '2019-05-03 20:00:48', '2020-05-03 20:00:48');
INSERT INTO `oauth_access_tokens` VALUES ('45a885012978aaf183fd066168f2c6f23a197bbe222bbfe6f83ad34b033f614c1a357f7fb5c0d04e', 2, 1, 'MyApp', '[]', 0, '2019-05-04 22:54:03', '2019-05-04 22:54:03', '2020-05-04 22:54:03');
INSERT INTO `oauth_access_tokens` VALUES ('4d4caf5f40e26b4a72f0297d52614c3e7eaccad48968f92f2b70213cafe88292f27c7a7c45d6e0ed', 2, 1, 'MyApp', '[]', 0, '2019-04-19 15:14:57', '2019-04-19 15:14:57', '2020-04-19 15:14:57');
INSERT INTO `oauth_access_tokens` VALUES ('4f056d2e9cd72c9ad50e8aea6433897ee11c07cd759a9774543bb897c527ccf17b62ad0ac96f69f7', 12, 1, 'MyApp', '[]', 0, '2019-05-07 22:47:20', '2019-05-07 22:47:20', '2020-05-07 22:47:20');
INSERT INTO `oauth_access_tokens` VALUES ('4fbd8497ab1161001d1233a3cb1ffc6d49e2da41460f608b476b2888d66efab58e761b8c9a19f75c', 2, 1, 'MyApp', '[]', 0, '2019-04-30 22:32:09', '2019-04-30 22:32:09', '2020-04-30 22:32:09');
INSERT INTO `oauth_access_tokens` VALUES ('54e6e5cfbd0547753525f23e7923a5e2d115f4c5fa87753ec185a22a93178a4d1f8a4c17d2c0f92a', 15, 1, 'MyApp', '[]', 0, '2019-05-11 09:27:34', '2019-05-11 09:27:34', '2020-05-11 09:27:34');
INSERT INTO `oauth_access_tokens` VALUES ('553abd13018c51106fb3245db77b36274db4b95eddb1c61a73b1722a3dd9a312cca093c7702c8e66', 2, 1, 'MyApp', '[]', 0, '2019-05-07 18:59:18', '2019-05-07 18:59:18', '2020-05-07 18:59:18');
INSERT INTO `oauth_access_tokens` VALUES ('5639c1e5da120bafe52a049a60419412e477a1608c1e9fa6682d40bb903d5d252697fdb7635d0f9b', 2, 1, 'MyApp', '[]', 0, '2019-04-25 08:23:43', '2019-04-25 08:23:43', '2020-04-25 08:23:43');
INSERT INTO `oauth_access_tokens` VALUES ('587fb93867dfa81b135fe374883068761a46d74293461a0f7fbe30e5077753a3e87c48dfa6be90db', 2, 1, 'MyApp', '[]', 0, '2019-04-12 11:12:38', '2019-04-12 11:12:38', '2020-04-12 11:12:38');
INSERT INTO `oauth_access_tokens` VALUES ('5db6b13492643a9a462c0dce4ce04a3d96df00ed18edbf0d26a1dac7d74271f69a084235734392ed', 2, 1, 'MyApp', '[]', 0, '2019-04-26 13:34:58', '2019-04-26 13:34:58', '2020-04-26 13:34:58');
INSERT INTO `oauth_access_tokens` VALUES ('603880efe258e0f330f18c1c3c7191736e04202a77e7639a02ab078889ff25becb9a30f0c77f4990', 15, 1, 'MyApp', '[]', 0, '2019-05-10 13:57:54', '2019-05-10 13:57:54', '2020-05-10 13:57:54');
INSERT INTO `oauth_access_tokens` VALUES ('62466961de48886a17f532889b3dc96ab4fcce3e13b524cd69acc6170eb867a69d3a3cde5e8b2c33', 2, 1, 'MyApp', '[]', 0, '2019-03-18 11:44:22', '2019-03-18 11:44:22', '2020-03-18 11:44:22');
INSERT INTO `oauth_access_tokens` VALUES ('637979837d6b444ddb73d3167055561ba2e8dd00d00c4c4825a5534a8d6e652388f6e612f41c886b', 2, 1, 'MyApp', '[]', 0, '2019-04-29 11:01:47', '2019-04-29 11:01:47', '2020-04-29 11:01:47');
INSERT INTO `oauth_access_tokens` VALUES ('63dfa383a47cfa371afc20909d422671e19543c81e9d40854f0c51d889e76040a670f38f773f2ebe', 2, 1, 'MyApp', '[]', 0, '2019-04-09 08:08:54', '2019-04-09 08:08:54', '2020-04-09 08:08:54');
INSERT INTO `oauth_access_tokens` VALUES ('64388e16751f491255693a2c8dc3138269820ee1b1e764abd125ca1fb2d808a738f92153c76931b5', 2, 1, 'MyApp', '[]', 0, '2019-03-22 14:11:53', '2019-03-22 14:11:53', '2020-03-22 14:11:53');
INSERT INTO `oauth_access_tokens` VALUES ('67306fcdc22aa5b8443942722784fc32d985baf4151f4bcada00a8969c0a6c4ea9bc6b9a801f1b45', 2, 1, 'MyApp', '[]', 0, '2019-04-18 15:18:25', '2019-04-18 15:18:25', '2020-04-18 15:18:25');
INSERT INTO `oauth_access_tokens` VALUES ('676d86f257186c95b4e61ef514c27bf1733b2d350dc1e0c6d404e38278c6373e085dd2a8aeeb2100', 2, 1, 'MyApp', '[]', 0, '2019-04-24 11:58:28', '2019-04-24 11:58:28', '2020-04-24 11:58:28');
INSERT INTO `oauth_access_tokens` VALUES ('69fb3f0f3d90f7f0c5fc8af0756a85974185ea7b721383b42532f440e3ef2dd9ae3ea7e4b3123c88', 2, 1, 'MyApp', '[]', 0, '2019-05-14 14:37:07', '2019-05-14 14:37:07', '2020-05-14 14:37:07');
INSERT INTO `oauth_access_tokens` VALUES ('6a8e04a0c74f204ed1225d7c19b13b15b7bee1afd94db125397ea001ebd7ae96d3643558695617a6', 2, 1, 'MyApp', '[]', 0, '2019-04-30 15:10:04', '2019-04-30 15:10:04', '2020-04-30 15:10:04');
INSERT INTO `oauth_access_tokens` VALUES ('6e98729a0c4e1e54fce7a96777dc287817a54f87519e047c0cc13b5aabe8f0df857446b0a9496fc0', 2, 1, 'MyApp', '[]', 0, '2019-04-12 15:45:29', '2019-04-12 15:45:29', '2020-04-12 15:45:29');
INSERT INTO `oauth_access_tokens` VALUES ('737a7e77bd8fd489f65d343a4fdf6e0f274b709c2f543196fef2bce4bd3daf54dfa581e7dfbbe6f8', 15, 1, 'MyApp', '[]', 0, '2019-05-08 22:13:47', '2019-05-08 22:13:47', '2020-05-08 22:13:47');
INSERT INTO `oauth_access_tokens` VALUES ('77155dd2d0ecd79c4847de3822b861f1773255e1067f8fdce0ccc60ee6588cfd67069813e74d309b', 2, 1, 'MyApp', '[]', 0, '2019-05-01 08:55:11', '2019-05-01 08:55:11', '2020-05-01 08:55:11');
INSERT INTO `oauth_access_tokens` VALUES ('7f0d3e0dde161325a88968a0e6ac03fb4c212d9af85e7592ffc34e969882c07f2b03b478aaacb368', 15, 1, 'MyApp', '[]', 0, '2019-05-10 13:58:35', '2019-05-10 13:58:35', '2020-05-10 13:58:35');
INSERT INTO `oauth_access_tokens` VALUES ('8082575ad3affa2f8fd574a6b89ea9c780beb27597c595792f95d569d6b948024f6c236892887fdb', 2, 1, 'MyApp', '[]', 0, '2019-05-08 21:07:41', '2019-05-08 21:07:41', '2020-05-08 21:07:41');
INSERT INTO `oauth_access_tokens` VALUES ('826e068d775d21d4a42be19cfa3b7442952e2dc15c6d9348c1ac5aa2e3167f9ac2939ed404043d5d', 2, 1, 'MyApp', '[]', 0, '2019-05-11 14:49:54', '2019-05-11 14:49:54', '2020-05-11 14:49:54');
INSERT INTO `oauth_access_tokens` VALUES ('991932e8988494f0559e93420d89944b3eb7ad7ad9046048915b19268abab6bb5cc1c62ee4cefca8', 2, 1, 'MyApp', '[]', 0, '2019-05-04 18:03:10', '2019-05-04 18:03:10', '2020-05-04 18:03:10');
INSERT INTO `oauth_access_tokens` VALUES ('9bba88e9d87e0ec78a35d5257ca44a10e77506eb4cfb606041ce3d3db9520067a5767ec9f150fb1c', 2, 1, 'MyApp', '[]', 0, '2019-04-17 08:46:50', '2019-04-17 08:46:50', '2020-04-17 08:46:50');
INSERT INTO `oauth_access_tokens` VALUES ('a079e3f003ea2847b1f53a00528b009d982dde864f8d3e4fea0c3aafa967f0694084d956aac112ba', 2, 1, 'MyApp', '[]', 0, '2019-05-13 08:08:57', '2019-05-13 08:08:57', '2020-05-13 08:08:57');
INSERT INTO `oauth_access_tokens` VALUES ('a3298a5df2ee219b30885500eb88dde4c825f8e90809c79dcc074eb13568ee39899fcd27f4c997c6', 2, 1, 'MyApp', '[]', 0, '2019-03-05 14:43:40', '2019-03-05 14:43:40', '2020-03-05 14:43:40');
INSERT INTO `oauth_access_tokens` VALUES ('a4a0d89cfacd2e4fa4ff8247f7a30acd12fb5adac78acb13f00cb1f66b2440f3dfd1616a8143abf4', 2, 1, 'MyApp', '[]', 0, '2019-03-06 08:23:41', '2019-03-06 08:23:41', '2020-03-06 08:23:41');
INSERT INTO `oauth_access_tokens` VALUES ('a7a8eae946a69943cd354815a800cd8823a8a3289b1b9b3f75bb1c7cf432546e0f9b065666e75da9', 2, 1, 'MyApp', '[]', 0, '2019-05-07 20:36:13', '2019-05-07 20:36:13', '2020-05-07 20:36:13');
INSERT INTO `oauth_access_tokens` VALUES ('aaa4922e63eaef2d316628fa41754a6ea34bde6c4998dc25c77d17fcdf9c4878d3d971b24dabf735', 2, 1, 'MyApp', '[]', 0, '2019-04-17 15:11:02', '2019-04-17 15:11:02', '2020-04-17 15:11:02');
INSERT INTO `oauth_access_tokens` VALUES ('ab868f37953c95ff2fe4eba6f02138cda88889d957d0e0d1fbcb6e3f7035ba4cfce82f5de6e6e275', 2, 1, 'MyApp', '[]', 0, '2019-04-08 15:11:24', '2019-04-08 15:11:24', '2020-04-08 15:11:24');
INSERT INTO `oauth_access_tokens` VALUES ('bb4f29906f22c4a681daa5ab02ac0dd7169f7c2478fa29ee3055b3c7849e361d3372d26ee01fa851', 15, 1, 'MyApp', '[]', 0, '2019-05-10 13:59:50', '2019-05-10 13:59:50', '2020-05-10 13:59:50');
INSERT INTO `oauth_access_tokens` VALUES ('bc770cf7927b373b75211a1c39489e6147cc4d9dabf35e708ff7c5a0bc8382e322992a739a4c3b67', 2, 1, 'MyApp', '[]', 0, '2019-04-24 14:44:39', '2019-04-24 14:44:39', '2020-04-24 14:44:39');
INSERT INTO `oauth_access_tokens` VALUES ('bcbed5ab3f6e097d6ad36bf6703f098f4954617ea8ca4946f4e9092267041d24430038e4f2bcc131', 2, 1, 'MyApp', '[]', 0, '2019-02-27 10:14:16', '2019-02-27 10:14:16', '2020-02-27 10:14:16');
INSERT INTO `oauth_access_tokens` VALUES ('be295188193163a7864d4368da2e87b8448b4933495a5d6d5b4e5f93a978081f8f9aae9cb5c860fb', 2, 1, 'MyApp', '[]', 0, '2019-04-24 08:08:03', '2019-04-24 08:08:03', '2020-04-24 08:08:03');
INSERT INTO `oauth_access_tokens` VALUES ('c37225ef1539303153ec7e3625f3c4c5c47f7c5183b2b32c208452a4d559dd66dfdc72580782022a', 2, 1, 'MyApp', '[]', 0, '2019-04-09 11:01:23', '2019-04-09 11:01:23', '2020-04-09 11:01:23');
INSERT INTO `oauth_access_tokens` VALUES ('c71c50272f464e51f02d0bfe55b937675318351fa2f0bc367d2acd201e27b983becd59f4dd518abe', 14, 1, 'MyApp', '[]', 0, '2019-05-08 22:11:56', '2019-05-08 22:11:56', '2020-05-08 22:11:56');
INSERT INTO `oauth_access_tokens` VALUES ('ca9087419ae0358f575af4a602fcecc0f2f54ebff8294f5c99e72d0b3d48e307e17f581b1eb80a15', 2, 1, 'MyApp', '[]', 0, '2019-04-18 08:32:48', '2019-04-18 08:32:48', '2020-04-18 08:32:48');
INSERT INTO `oauth_access_tokens` VALUES ('caa5829e589e32b969468fae1ad69e03ecdd69b997018399dd9fd21910838e943e0d0658f6f033e0', 11, 1, 'MyApp', '[]', 0, '2019-05-07 20:30:27', '2019-05-07 20:30:27', '2020-05-07 20:30:27');
INSERT INTO `oauth_access_tokens` VALUES ('cb694bfb52d361c2bef04d22bd8eca368f6889fbda88e1237b31841eab18ffae7f3c894d7d527fcf', 2, 1, 'MyApp', '[]', 0, '2019-04-20 08:22:12', '2019-04-20 08:22:12', '2020-04-20 08:22:12');
INSERT INTO `oauth_access_tokens` VALUES ('d13f0c2e4c697c9d7b266da46569f284d4b6dc87ae1a512b0afa005205e85a1ce2a2cc966684a4f4', 2, 1, 'MyApp', '[]', 0, '2019-04-13 08:19:03', '2019-04-13 08:19:03', '2020-04-13 08:19:03');
INSERT INTO `oauth_access_tokens` VALUES ('d5a2198f95ff44e5489155d375ff56a2b76a8ad74dc269ffa14eaa7f6e9298f5492a0b21da638837', 9, 1, 'MyApp', '[]', 0, '2019-05-07 19:17:11', '2019-05-07 19:17:11', '2020-05-07 19:17:11');
INSERT INTO `oauth_access_tokens` VALUES ('d6a04bb62fee99a1c1caf96009a1e00a376a48fc772a1e7cf6c708bf3425f072b5cd16f0e84c6af9', 2, 1, 'MyApp', '[]', 0, '2019-05-05 16:24:06', '2019-05-05 16:24:06', '2020-05-05 16:24:06');
INSERT INTO `oauth_access_tokens` VALUES ('d8a7b0ea0070cc35b5a07d42d6df6e2926eda9100cc5ef6a467762daeae19adf69f3df298802ab6a', 2, 1, 'MyApp', '[]', 0, '2019-05-13 15:28:54', '2019-05-13 15:28:54', '2020-05-13 15:28:54');
INSERT INTO `oauth_access_tokens` VALUES ('d932de0315dd2f36c812034d2205b4049a0057b245cc342b4eb57c12b821ed4ca42681ac12cc3ee2', 2, 1, 'MyApp', '[]', 0, '2019-03-06 15:07:14', '2019-03-06 15:07:14', '2020-03-06 15:07:14');
INSERT INTO `oauth_access_tokens` VALUES ('de33d617088f439eff8047790a638319db10e5480f541fe15e1214998ab469ecc3e45da83855d4a6', 13, 1, 'MyApp', '[]', 0, '2019-05-08 22:05:35', '2019-05-08 22:05:35', '2020-05-08 22:05:35');
INSERT INTO `oauth_access_tokens` VALUES ('ea941ba89a58f6f69ffbfb65dbe8102486e5aee43526e3cc9ecc54db4dcfe71fb8db3d52882594de', 2, 1, 'MyApp', '[]', 0, '2019-02-28 08:53:52', '2019-02-28 08:53:52', '2020-02-28 08:53:52');
INSERT INTO `oauth_access_tokens` VALUES ('edd8592520c0805f08f3f4cb50be68a5dc7341d4061acdaada73e547da129b06e5553c1211d2051f', 2, 1, 'MyApp', '[]', 0, '2019-03-02 08:09:02', '2019-03-02 08:09:02', '2020-03-02 08:09:02');
INSERT INTO `oauth_access_tokens` VALUES ('eebcb8b6c0881d51285f1b3175057a4d91c17aa90281daee2bf4b3fb622847bb7f493f11e12e601c', 2, 1, 'MyApp', '[]', 0, '2019-03-21 17:01:19', '2019-03-21 17:01:19', '2020-03-21 17:01:19');
INSERT INTO `oauth_access_tokens` VALUES ('f440d733d86874bd55e90f565f8122efa04c3cb5f89a3cab2dda3c626a2ac803a1c7cfabe4e86592', 2, 1, 'MyApp', '[]', 0, '2019-05-10 14:00:20', '2019-05-10 14:00:20', '2020-05-10 14:00:20');
INSERT INTO `oauth_access_tokens` VALUES ('f5e2b2f0195eb9946ada086c63c04d82b8e94d3015d4594f0b19659ef043f8966699c000faab1bd0', 2, 1, 'MyApp', '[]', 0, '2019-05-10 08:23:58', '2019-05-10 08:23:58', '2020-05-10 08:23:58');
INSERT INTO `oauth_access_tokens` VALUES ('f66ca15e94fd11f4fa3b5e497355be704e3ba4a7b7bed055d0d543fea64fbcd3e16f51bf90090567', 2, 1, 'MyApp', '[]', 0, '2019-04-23 13:36:16', '2019-04-23 13:36:16', '2020-04-23 13:36:16');
INSERT INTO `oauth_access_tokens` VALUES ('f867dd75382d40379874b24a53ecf5272cb6696d47fa8331452cf0a43cd5bdb24e0339908f3f3aab', 2, 1, 'MyApp', '[]', 0, '2019-04-22 17:26:22', '2019-04-22 17:26:22', '2020-04-22 17:26:22');
INSERT INTO `oauth_access_tokens` VALUES ('fb452856dc1b66b6002da8863caef9b17730072341ad6c5fbd0b716f61abf8792b4b9b0dcc6e44ee', 5, 1, 'MyApp', '[]', 0, '2019-05-05 21:54:13', '2019-05-05 21:54:13', '2020-05-05 21:54:13');

-- ----------------------------
-- Table structure for oauth_auth_codes
-- ----------------------------
DROP TABLE IF EXISTS `oauth_auth_codes`;
CREATE TABLE `oauth_auth_codes`  (
  `id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `client_id` int(10) UNSIGNED NOT NULL,
  `scopes` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for oauth_clients
-- ----------------------------
DROP TABLE IF EXISTS `oauth_clients`;
CREATE TABLE `oauth_clients`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NULL DEFAULT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `secret` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `redirect` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_access_client` tinyint(1) NOT NULL,
  `password_client` tinyint(1) NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `oauth_clients_user_id_index`(`user_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of oauth_clients
-- ----------------------------
INSERT INTO `oauth_clients` VALUES (1, NULL, 'Laravel Personal Access Client', 'pKAxvNpKupq4MXxptmzvuT38ByuPIWyKv87fuiQt', 'http://localhost', 1, 0, 0, '2019-02-27 09:46:34', '2019-02-27 09:46:34');
INSERT INTO `oauth_clients` VALUES (2, NULL, 'Laravel Password Grant Client', '4Djvc7dyJChiOr3UGmcYTjI0OrpCFenogIdusJDM', 'http://localhost', 0, 1, 0, '2019-02-27 09:46:34', '2019-02-27 09:46:34');

-- ----------------------------
-- Table structure for oauth_personal_access_clients
-- ----------------------------
DROP TABLE IF EXISTS `oauth_personal_access_clients`;
CREATE TABLE `oauth_personal_access_clients`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `client_id` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `oauth_personal_access_clients_client_id_index`(`client_id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of oauth_personal_access_clients
-- ----------------------------
INSERT INTO `oauth_personal_access_clients` VALUES (1, 1, '2019-02-27 09:46:34', '2019-02-27 09:46:34');

-- ----------------------------
-- Table structure for oauth_refresh_tokens
-- ----------------------------
DROP TABLE IF EXISTS `oauth_refresh_tokens`;
CREATE TABLE `oauth_refresh_tokens`  (
  `id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `access_token_id` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `revoked` tinyint(1) NOT NULL,
  `expires_at` datetime(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `oauth_refresh_tokens_access_token_id_index`(`access_token_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for password_resets
-- ----------------------------
DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets`  (
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  INDEX `password_resets_email_index`(`email`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for permissions
-- ----------------------------
DROP TABLE IF EXISTS `permissions`;
CREATE TABLE `permissions`  (
  `idperm` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`idperm`) USING BTREE,
  UNIQUE INDEX `permissions_name_unique`(`name`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of permissions
-- ----------------------------
INSERT INTO `permissions` VALUES (1, 'root', 'Quản trị hệ thống', '2019-04-13 08:30:03', '2019-04-13 08:30:03');

-- ----------------------------
-- Table structure for post_has_files
-- ----------------------------
DROP TABLE IF EXISTS `post_has_files`;
CREATE TABLE `post_has_files`  (
  `idhasfile` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `idpost` bigint(20) NULL DEFAULT NULL,
  `hastype` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `idfile` int(11) NULL DEFAULT NULL,
  `created_at` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0),
  PRIMARY KEY (`idhasfile`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 50 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of post_has_files
-- ----------------------------
INSERT INTO `post_has_files` VALUES (1, 1, 'image', 13, '2019-03-21 16:20:00', '2019-03-21 16:20:00');
INSERT INTO `post_has_files` VALUES (2, 2, 'image', 10, '2019-04-08 16:58:04', '2019-04-08 16:58:04');
INSERT INTO `post_has_files` VALUES (3, 3, 'image', 0, '2019-04-08 17:00:32', '2019-04-08 17:00:32');
INSERT INTO `post_has_files` VALUES (4, 4, 'image', 0, '2019-04-08 17:11:50', '2019-04-08 17:11:50');
INSERT INTO `post_has_files` VALUES (5, 5, 'image', 1, '2019-04-08 17:18:31', '2019-04-08 17:18:31');
INSERT INTO `post_has_files` VALUES (6, 6, 'image', 0, '2019-04-08 17:25:11', '2019-04-08 17:25:11');
INSERT INTO `post_has_files` VALUES (7, 7, 'image', 10, '2019-04-08 17:41:51', '2019-04-08 17:41:51');
INSERT INTO `post_has_files` VALUES (8, 8, 'image', 0, '2019-04-08 17:43:04', '2019-04-08 17:43:04');
INSERT INTO `post_has_files` VALUES (9, 9, 'image', 0, '2019-04-09 08:08:20', '2019-04-09 08:08:20');
INSERT INTO `post_has_files` VALUES (10, 10, 'image', 2, '2019-04-09 08:10:16', '2019-04-09 08:10:16');
INSERT INTO `post_has_files` VALUES (11, 11, 'image', 0, '2019-04-09 08:12:34', '2019-04-09 08:12:34');
INSERT INTO `post_has_files` VALUES (12, 12, 'image', 0, '2019-04-09 08:13:26', '2019-04-09 08:13:26');
INSERT INTO `post_has_files` VALUES (13, 13, 'image', 0, '2019-04-09 11:17:42', '2019-04-09 11:17:42');
INSERT INTO `post_has_files` VALUES (14, 14, 'image', 0, '2019-04-09 11:18:24', '2019-04-09 11:18:24');
INSERT INTO `post_has_files` VALUES (15, 15, 'image', 0, '2019-04-10 08:06:24', '2019-04-10 08:06:24');
INSERT INTO `post_has_files` VALUES (16, 16, 'image', 3, '2019-04-10 08:06:59', '2019-04-10 08:06:59');
INSERT INTO `post_has_files` VALUES (17, 17, 'image', 0, '2019-04-10 15:11:27', '2019-04-10 15:11:27');
INSERT INTO `post_has_files` VALUES (18, 18, 'image', 0, '2019-04-11 08:16:44', '2019-04-11 08:16:44');
INSERT INTO `post_has_files` VALUES (19, 19, 'image', 0, '2019-04-11 08:17:10', '2019-04-11 08:17:10');
INSERT INTO `post_has_files` VALUES (20, 20, 'image', 0, '2019-04-11 11:01:21', '2019-04-11 11:01:21');
INSERT INTO `post_has_files` VALUES (21, 21, 'image', 0, '2019-04-12 11:18:31', '2019-04-12 11:18:31');
INSERT INTO `post_has_files` VALUES (22, 22, 'image', 0, '2019-04-12 11:19:40', '2019-04-12 11:19:40');
INSERT INTO `post_has_files` VALUES (23, 23, 'image', 0, '2019-04-13 08:20:02', '2019-04-13 08:20:02');
INSERT INTO `post_has_files` VALUES (24, 24, 'image', 0, '2019-04-17 08:50:18', '2019-04-17 08:50:18');
INSERT INTO `post_has_files` VALUES (25, 25, 'image', 0, '2019-04-17 09:12:53', '2019-04-17 09:12:53');
INSERT INTO `post_has_files` VALUES (26, 26, 'image', 12, '2019-04-17 10:35:14', '2019-04-17 10:35:14');
INSERT INTO `post_has_files` VALUES (27, 27, 'image', 0, '2019-04-17 10:43:39', '2019-04-17 10:43:39');
INSERT INTO `post_has_files` VALUES (28, 28, 'image', 1, '2019-04-17 10:51:55', '2019-04-17 10:51:55');
INSERT INTO `post_has_files` VALUES (29, 29, 'image', 0, '2019-04-18 08:34:13', '2019-04-18 08:34:13');
INSERT INTO `post_has_files` VALUES (30, 30, 'image', 0, '2019-04-18 10:07:14', '2019-04-18 10:07:14');
INSERT INTO `post_has_files` VALUES (31, 31, 'image', 0, '2019-04-19 15:16:24', '2019-04-19 15:16:24');
INSERT INTO `post_has_files` VALUES (32, 41, 'image', 0, '2019-04-22 11:29:39', '2019-04-22 11:29:39');
INSERT INTO `post_has_files` VALUES (33, 45, 'image', 0, '2019-04-23 15:43:46', '2019-04-23 15:43:46');
INSERT INTO `post_has_files` VALUES (34, 46, 'image', 0, '2019-04-23 16:54:45', '2019-04-23 16:54:45');
INSERT INTO `post_has_files` VALUES (35, 47, 'image', 0, '2019-04-24 11:58:14', '2019-04-24 11:58:14');
INSERT INTO `post_has_files` VALUES (36, 48, 'image', 0, '2019-04-24 12:01:21', '2019-04-24 12:01:21');
INSERT INTO `post_has_files` VALUES (37, 49, 'image', 0, '2019-04-24 12:01:49', '2019-04-24 12:01:49');
INSERT INTO `post_has_files` VALUES (38, 90, 'image', 9, '2019-05-13 15:15:16', '2019-05-13 15:15:16');
INSERT INTO `post_has_files` VALUES (39, 91, 'image', 10, '2019-05-13 15:31:49', '2019-05-13 15:31:49');
INSERT INTO `post_has_files` VALUES (40, 92, 'image', 0, '2019-05-14 14:36:40', '2019-05-14 14:36:40');
INSERT INTO `post_has_files` VALUES (41, 93, 'image', 0, '2019-05-14 15:01:06', '2019-05-14 15:01:06');
INSERT INTO `post_has_files` VALUES (42, 94, 'image', 0, '2019-05-14 15:23:35', '2019-05-14 15:23:35');
INSERT INTO `post_has_files` VALUES (43, 95, 'image', 0, '2019-05-14 15:41:50', '2019-05-14 15:41:50');
INSERT INTO `post_has_files` VALUES (44, 96, 'image', 0, '2019-05-14 15:46:14', '2019-05-14 15:46:14');
INSERT INTO `post_has_files` VALUES (45, 97, 'image', 0, '2019-05-14 15:48:18', '2019-05-14 15:48:18');
INSERT INTO `post_has_files` VALUES (46, 98, 'image', 0, '2019-05-14 15:50:31', '2019-05-14 15:50:31');
INSERT INTO `post_has_files` VALUES (47, 99, 'image', 0, '2019-05-14 16:19:02', '2019-05-14 16:19:02');
INSERT INTO `post_has_files` VALUES (48, 100, 'image', 0, '2019-05-14 16:24:45', '2019-05-14 16:24:45');
INSERT INTO `post_has_files` VALUES (49, 101, 'image', 0, '2019-05-14 16:29:54', '2019-05-14 16:29:54');

-- ----------------------------
-- Table structure for post_types
-- ----------------------------
DROP TABLE IF EXISTS `post_types`;
CREATE TABLE `post_types`  (
  `idposttype` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `nametype` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idparent` int(11) NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`idposttype`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of post_types
-- ----------------------------
INSERT INTO `post_types` VALUES (1, 'consultant', 1, '2019-04-17 08:49:25', '2019-04-17 08:49:25');
INSERT INTO `post_types` VALUES (2, 'promotion', 1, '2019-04-17 08:49:41', '2019-04-17 08:49:41');
INSERT INTO `post_types` VALUES (3, 'post', NULL, '2019-04-17 10:06:34', '2019-04-17 10:06:34');
INSERT INTO `post_types` VALUES (4, 'phone', 4, '2019-04-17 11:44:28', '2019-04-17 11:44:28');
INSERT INTO `post_types` VALUES (5, 'sms', 4, '2019-04-17 11:44:44', '2019-04-17 11:44:44');
INSERT INTO `post_types` VALUES (6, 'email', 4, '2019-04-17 15:37:20', '2019-04-17 15:37:20');
INSERT INTO `post_types` VALUES (7, 'booking', 4, '2019-04-25 11:36:00', '2019-04-25 11:36:00');
INSERT INTO `post_types` VALUES (8, 'note', 4, '2019-05-13 15:17:17', '2019-05-13 15:17:17');

-- ----------------------------
-- Table structure for posts
-- ----------------------------
DROP TABLE IF EXISTS `posts`;
CREATE TABLE `posts`  (
  `idpost` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `body` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `slug` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `id_post_type` int(11) NULL DEFAULT NULL,
  `idcategory` int(11) NULL DEFAULT NULL,
  `created_at` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0),
  PRIMARY KEY (`idpost`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 102 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of posts
-- ----------------------------
INSERT INTO `posts` VALUES (24, NULL, 'http://localhost/thammy/#,Bình Dương', NULL, 1, 2, '2019-04-17 08:50:18', '2019-04-17 08:50:18');
INSERT INTO `posts` VALUES (25, NULL, 'http://localhost/thammy/tiem-cang-bong-da-mat-baby-face/,Bình Dương', NULL, 2, 2, '2019-04-17 09:12:53', '2019-04-17 09:39:35');
INSERT INTO `posts` VALUES (26, NULL, 'url', NULL, 2, 3, '2019-04-17 10:35:14', '2019-04-17 10:35:14');
INSERT INTO `posts` VALUES (27, NULL, 'http://localhost/thammy/#,Bình Dương', NULL, 1, 2, '2019-04-17 10:43:39', '2019-04-17 10:43:39');
INSERT INTO `posts` VALUES (28, NULL, 'url test', NULL, 2, 3, '2019-04-17 10:51:55', '2019-04-17 10:51:55');
INSERT INTO `posts` VALUES (29, NULL, 'http://localhost/thammy/tiem-cang-bong-da-mat-baby-face/', NULL, 2, 2, '2019-04-18 08:34:13', '2019-04-18 08:34:13');
INSERT INTO `posts` VALUES (30, NULL, 'http://localhost/thammy/demo-dang-ky-tuy-bien/', NULL, 2, 2, '2019-04-18 10:07:14', '2019-04-18 10:07:14');
INSERT INTO `posts` VALUES (31, NULL, 'http://localhost/thammy/tiem-cang-bong-da-mat-baby-face/', NULL, 2, 2, '2019-04-19 15:16:24', '2019-04-19 15:16:24');
INSERT INTO `posts` VALUES (40, NULL, 'không bắt máy', NULL, 4, NULL, '2019-04-19 16:00:14', '2019-04-19 16:00:14');
INSERT INTO `posts` VALUES (41, NULL, 'http://localhost/thammy/#', NULL, 1, 2, '2019-04-22 11:29:39', '2019-04-22 11:29:39');
INSERT INTO `posts` VALUES (42, NULL, 'không bắt máy', NULL, 4, NULL, '2019-04-22 14:15:47', '2019-04-22 14:15:47');
INSERT INTO `posts` VALUES (43, NULL, NULL, NULL, NULL, NULL, '2019-04-22 14:23:50', '2019-04-22 14:23:50');
INSERT INTO `posts` VALUES (44, NULL, 'không bắt máy', NULL, NULL, NULL, '2019-04-22 14:30:12', '2019-04-22 14:30:12');
INSERT INTO `posts` VALUES (45, NULL, 'http://localhost/thammy/#', NULL, 1, 2, '2019-04-23 15:43:46', '2019-04-23 15:43:46');
INSERT INTO `posts` VALUES (46, NULL, 'http://localhost/thammy/tiem-cang-bong-da-mat-baby-face/', NULL, 2, 2, '2019-04-23 16:54:45', '2019-04-23 16:54:45');
INSERT INTO `posts` VALUES (47, NULL, 'http://localhost/thammy/#', NULL, 1, 2, '2019-04-24 11:58:14', '2019-04-24 11:58:14');
INSERT INTO `posts` VALUES (48, NULL, 'http://localhost/thammy/tiem-cang-bong-da-mat-baby-face/', NULL, 2, 2, '2019-04-24 12:01:21', '2019-04-24 12:01:21');
INSERT INTO `posts` VALUES (49, NULL, 'http://localhost/thammy/tiem-cang-bong-da-mat-baby-face/', NULL, 2, 2, '2019-04-24 12:01:49', '2019-04-24 12:01:49');
INSERT INTO `posts` VALUES (50, NULL, 'đã gọi điện thoại', NULL, 4, NULL, '2019-04-24 12:03:12', '2019-04-24 12:03:12');
INSERT INTO `posts` VALUES (51, NULL, 'đã tiếp nhận', NULL, 4, NULL, '2019-04-24 16:19:47', '2019-04-24 16:19:47');
INSERT INTO `posts` VALUES (52, NULL, 'đã tư vấn', NULL, 4, NULL, '2019-04-24 17:14:38', '2019-04-24 17:14:38');
INSERT INTO `posts` VALUES (53, NULL, NULL, NULL, 7, NULL, '2019-04-30 22:55:12', '2019-04-30 22:55:12');
INSERT INTO `posts` VALUES (54, NULL, NULL, NULL, NULL, NULL, '2019-04-30 23:01:52', '2019-04-30 23:01:52');
INSERT INTO `posts` VALUES (55, NULL, NULL, NULL, 7, NULL, '2019-04-30 23:02:07', '2019-04-30 23:02:07');
INSERT INTO `posts` VALUES (56, NULL, 'đặt lịch', NULL, 7, NULL, '2019-04-30 23:04:01', '2019-04-30 23:04:01');
INSERT INTO `posts` VALUES (57, NULL, 'đặt lịch', NULL, 7, NULL, '2019-04-30 23:07:24', '2019-04-30 23:07:24');
INSERT INTO `posts` VALUES (58, NULL, NULL, NULL, NULL, NULL, '2019-04-30 23:09:37', '2019-04-30 23:09:37');
INSERT INTO `posts` VALUES (59, NULL, NULL, NULL, NULL, NULL, '2019-04-30 23:18:23', '2019-04-30 23:18:23');
INSERT INTO `posts` VALUES (60, NULL, NULL, NULL, NULL, NULL, '2019-04-30 23:19:25', '2019-04-30 23:19:25');
INSERT INTO `posts` VALUES (61, NULL, NULL, NULL, NULL, NULL, '2019-04-30 23:23:56', '2019-04-30 23:23:56');
INSERT INTO `posts` VALUES (62, NULL, 'gửi tin nhắn', NULL, 5, NULL, '2019-04-30 23:25:12', '2019-04-30 23:25:12');
INSERT INTO `posts` VALUES (63, NULL, 'gửi email', NULL, 6, NULL, '2019-04-30 23:27:55', '2019-04-30 23:27:55');
INSERT INTO `posts` VALUES (64, NULL, 'gửi email', NULL, 6, NULL, '2019-04-30 23:30:04', '2019-04-30 23:30:04');
INSERT INTO `posts` VALUES (65, NULL, 'Đặt lich', NULL, 7, NULL, '2019-04-30 23:30:42', '2019-04-30 23:30:42');
INSERT INTO `posts` VALUES (66, NULL, NULL, NULL, NULL, NULL, '2019-04-30 23:31:45', '2019-04-30 23:31:45');
INSERT INTO `posts` VALUES (67, NULL, 'dat lich', NULL, 7, NULL, '2019-05-01 17:37:55', '2019-05-01 17:37:55');
INSERT INTO `posts` VALUES (68, NULL, 'sms', NULL, 5, NULL, '2019-05-01 17:38:24', '2019-05-01 17:38:24');
INSERT INTO `posts` VALUES (69, NULL, 'chưa sắp xếp lịch', NULL, 4, NULL, '2019-05-01 18:08:40', '2019-05-01 18:08:40');
INSERT INTO `posts` VALUES (70, NULL, 'sms', NULL, 5, NULL, '2019-05-01 18:19:24', '2019-05-01 18:19:24');
INSERT INTO `posts` VALUES (71, NULL, 'đặt lịch 01/05/2019', NULL, 7, NULL, '2019-05-01 18:23:36', '2019-05-01 18:23:36');
INSERT INTO `posts` VALUES (72, NULL, 'đặt lịch', NULL, 7, NULL, '2019-05-01 18:36:07', '2019-05-01 18:36:07');
INSERT INTO `posts` VALUES (73, NULL, 'trong tuần sau sẽ trả lời', NULL, 4, NULL, '2019-05-01 21:11:04', '2019-05-01 21:11:04');
INSERT INTO `posts` VALUES (74, NULL, 'gửi sms', NULL, 5, NULL, '2019-05-01 21:17:46', '2019-05-01 21:17:46');
INSERT INTO `posts` VALUES (75, NULL, 'đặt lịch ví dụ', NULL, 7, NULL, '2019-05-01 21:23:30', '2019-05-01 21:23:30');
INSERT INTO `posts` VALUES (76, NULL, 'đặt thêm', NULL, 6, NULL, '2019-05-01 21:24:28', '2019-05-01 21:24:28');
INSERT INTO `posts` VALUES (77, NULL, 'gọi điện thoại', NULL, 4, NULL, '2019-05-01 21:25:03', '2019-05-01 21:25:03');
INSERT INTO `posts` VALUES (78, NULL, 'gửi email', NULL, 6, NULL, '2019-05-01 21:33:05', '2019-05-01 21:33:05');
INSERT INTO `posts` VALUES (79, NULL, 'tư vấn', NULL, 4, NULL, '2019-05-01 21:45:39', '2019-05-01 21:45:39');
INSERT INTO `posts` VALUES (80, NULL, 'chưa bắt máy', NULL, 4, NULL, '2019-05-01 22:00:23', '2019-05-01 22:00:23');
INSERT INTO `posts` VALUES (81, NULL, 'gửi tin nhắn', NULL, 5, NULL, '2019-05-01 22:00:45', '2019-05-01 22:00:45');
INSERT INTO `posts` VALUES (82, NULL, 'đặt lịch vào ngày 01/05/2019', NULL, 7, NULL, '2019-05-01 22:04:26', '2019-05-01 22:04:26');
INSERT INTO `posts` VALUES (83, NULL, 'không bắt máy', NULL, 4, NULL, '2019-05-01 22:37:34', '2019-05-01 22:37:34');
INSERT INTO `posts` VALUES (84, NULL, 'gọi lần 2, kh chưa xếp lịch đươc', NULL, 4, NULL, '2019-05-01 22:38:12', '2019-05-01 22:38:12');
INSERT INTO `posts` VALUES (85, NULL, 'máy bận', NULL, 4, NULL, '2019-05-03 20:02:04', '2019-05-03 20:02:04');
INSERT INTO `posts` VALUES (86, NULL, 'đặt lịch', NULL, 7, NULL, '2019-05-03 20:03:01', '2019-05-03 20:03:01');
INSERT INTO `posts` VALUES (87, NULL, 'gửi tin nhắn', NULL, 5, NULL, '2019-05-03 20:20:47', '2019-05-03 20:20:47');
INSERT INTO `posts` VALUES (88, NULL, 'chưa sếp lịch', NULL, 4, NULL, '2019-05-03 20:26:43', '2019-05-03 20:26:43');
INSERT INTO `posts` VALUES (89, NULL, 'ngày 04/05/2019', NULL, 7, NULL, '2019-05-04 18:11:27', '2019-05-04 18:11:27');
INSERT INTO `posts` VALUES (90, NULL, 'http://localhost/thammy/#', NULL, 1, 2, '2019-05-13 15:15:16', '2019-05-13 15:15:16');
INSERT INTO `posts` VALUES (91, NULL, 'http://localhost/beauty/#', NULL, 1, 2, '2019-05-13 15:31:49', '2019-05-13 15:31:49');
INSERT INTO `posts` VALUES (92, NULL, '<p><img src=\'uploads/2019/05/14/20190514_1557819400_5cda7008531ba.png\'/></p><p><img src=\'uploads/2019/05/14/20190514_1557819400_5cda70086ba2d.png\'/></p><p><img src=\'uploads/2019/05/14/20190514_1557819400_5cda70087290a.png\'/></p>', NULL, 1, 2, '2019-05-14 14:36:40', '2019-05-14 14:36:40');
INSERT INTO `posts` VALUES (93, NULL, '<p>Cân nặng:12,23</p><p>Bụng:100&nbsp;&nbsp;&nbsp;Bắp tay:100</p><p>Eo:100&nbsp;&nbsp;&nbsp;Đùi:100</p><p>Bạn đã từng giảm béo chưa?:Đã từng\n</p><p>Nếu có vì sao bạn lại không sử dụng phương pháp đó nữa ?</p><p>Phuong pháp</p><p>Câu chuyện thuyết phục ban giám khảo?:</p><p>cau chuyện</p><p>Bạn mong muốn điều gì khi tham gia chương trình?</p><p>chuong trình</p><p>Nếu được chọn trở thành gương mặt đại diện, bạn sẵn sàng tham gia liệu trình giảm béo Hiulther Lipase trong khoảng 1-2 tháng chứ ?</p><p>Sẵn sàng\n</p><p>Hãy gửi kèm 03 hình ảnh cá nhân mới nhất của bạn (1 ảnh cận đứng, 1 ảnh cận ngồi và 1 ảnh cận vùng cơ thể bạn muốn giảm nhất) cho chúng tôi kèm theo bản đăng ký tham gia này</p><p><img src=\'uploads/2019/05/14/20190514_1557820866_5cda75c2434e0.png\' /></p><p><img src=\'uploads/2019/05/14/20190514_1557820866_5cda75c24ca7e.png\' /></p><p><img src=\'uploads/2019/05/14/20190514_1557820866_5cda75c256bfc.png\' /></p>', NULL, 1, 2, '2019-05-14 15:01:06', '2019-05-14 15:01:06');
INSERT INTO `posts` VALUES (94, NULL, '<p>Cân nặng:12,23</p><p>Bụng:10&nbsp;&nbsp;&nbsp;Bắp tay:10</p><p>Eo:20&nbsp;&nbsp;&nbsp;Đùi:10</p><p>Bạn đã từng giảm béo chưa?:Đã từng\n</p><p>Nếu có vì sao bạn lại không sử dụng phương pháp đó nữa ?</p><p>phuong pháp</p><p>Câu chuyện thuyết phục ban giám khảo?:</p><p>câu chuyện thuyết phục</p><p>Bạn mong muốn điều gì khi tham gia chương trình?</p><p>mong muốn khi tham gia chương trình</p><p>Nếu được chọn trở thành gương mặt đại diện, bạn sẵn sàng tham gia liệu trình giảm béo Hiulther Lipase trong khoảng 1-2 tháng chứ ?</p><p>Sẵn sàng\n</p><p>Hãy gửi kèm 03 hình ảnh cá nhân mới nhất của bạn (1 ảnh cận đứng, 1 ảnh cận ngồi và 1 ảnh cận vùng cơ thể bạn muốn giảm nhất) cho chúng tôi kèm theo bản đăng ký tham gia này</p><p><img src=\'C:\\xampp\\htdocs\\marketing\\storage\\/uploads/2019/05/14/20190514_1557822215_5cda7b0737af4.png\' /></p><p><img src=\'C:\\xampp\\htdocs\\marketing\\storage\\/uploads/2019/05/14/20190514_1557822215_5cda7b0742668.png\' /></p><p><img src=\'C:\\xampp\\htdocs\\marketing\\storage\\/uploads/2019/05/14/20190514_1557822215_5cda7b074fe87.png\' /></p>', NULL, 1, 2, '2019-05-14 15:23:35', '2019-05-14 15:23:35');
INSERT INTO `posts` VALUES (95, NULL, '<p>Cân nặng:12,23</p><p>Bụng:10&nbsp;&nbsp;&nbsp;Bắp tay:100</p><p>Eo:10&nbsp;&nbsp;&nbsp;Đùi:10</p><p>Bạn đã từng giảm béo chưa?:Đã từng\n</p><p>Nếu có vì sao bạn lại không sử dụng phương pháp đó nữa ?</p><p>vi sao</p><p>Câu chuyện thuyết phục ban giám khảo?:</p><p>câu chuyện</p><p>Bạn mong muốn điều gì khi tham gia chương trình?</p><p>chương trình mong muốn</p><p>Nếu được chọn trở thành gương mặt đại diện, bạn sẵn sàng tham gia liệu trình giảm béo Hiulther Lipase trong khoảng 1-2 tháng chứ ?</p><p>Sẵn sàng\n</p><p>Hãy gửi kèm 03 hình ảnh cá nhân mới nhất của bạn (1 ảnh cận đứng, 1 ảnh cận ngồi và 1 ảnh cận vùng cơ thể bạn muốn giảm nhất) cho chúng tôi kèm theo bản đăng ký tham gia này</p><p><img src=\'{{ asset(uploads/2019/05/14/20190514_1557823309_5cda7f4de846e.png)}}\' /></p><p><img src=\'{{ asset(uploads/2019/05/14/20190514_1557823310_5cda7f4e022f8.png)}}\' /></p><p><img src=\'{{ asset(uploads/2019/05/14/20190514_1557823310_5cda7f4e0e54f.png)}}\' /></p>', NULL, 1, 2, '2019-05-14 15:41:50', '2019-05-14 15:41:50');
INSERT INTO `posts` VALUES (96, NULL, '<p>Cân nặng:12,23</p><p>Bụng:10&nbsp;&nbsp;&nbsp;Bắp tay:10</p><p>Eo:10&nbsp;&nbsp;&nbsp;Đùi:10</p><p>Bạn đã từng giảm béo chưa?:Chưa từng\n</p><p>Nếu có vì sao bạn lại không sử dụng phương pháp đó nữa ?</p><p>chưa tung62</p><p>Câu chuyện thuyết phục ban giám khảo?:</p><p>câu chuyện</p><p>Bạn mong muốn điều gì khi tham gia chương trình?</p><p>chnong</p><p>Nếu được chọn trở thành gương mặt đại diện, bạn sẵn sàng tham gia liệu trình giảm béo Hiulther Lipase trong khoảng 1-2 tháng chứ ?</p><p>Sẵn sàng\n</p><p>Hãy gửi kèm 03 hình ảnh cá nhân mới nhất của bạn (1 ảnh cận đứng, 1 ảnh cận ngồi và 1 ảnh cận vùng cơ thể bạn muốn giảm nhất) cho chúng tôi kèm theo bản đăng ký tham gia này</p><p><img src=\'localhostuploads/2019/05/14/20190514_1557823573_5cda8055c4dca.png\' /></p><p><img src=\'localhostuploads/2019/05/14/20190514_1557823573_5cda8055d4757.png\' /></p><p><img src=\'localhostuploads/2019/05/14/20190514_1557823573_5cda8055dee26.png\' /></p>', NULL, 1, 2, '2019-05-14 15:46:13', '2019-05-14 15:46:13');
INSERT INTO `posts` VALUES (97, NULL, '<p>Cân nặng:12,23</p><p>Bụng:10&nbsp;&nbsp;&nbsp;Bắp tay:10</p><p>Eo:10&nbsp;&nbsp;&nbsp;Đùi:10</p><p>Bạn đã từng giảm béo chưa?:Chưa từng\n</p><p>Nếu có vì sao bạn lại không sử dụng phương pháp đó nữa ?</p><p>chưa tung62</p><p>Câu chuyện thuyết phục ban giám khảo?:</p><p>câu chuyện</p><p>Bạn mong muốn điều gì khi tham gia chương trình?</p><p>chnong</p><p>Nếu được chọn trở thành gương mặt đại diện, bạn sẵn sàng tham gia liệu trình giảm béo Hiulther Lipase trong khoảng 1-2 tháng chứ ?</p><p>Sẵn sàng\n</p><p>Hãy gửi kèm 03 hình ảnh cá nhân mới nhất của bạn (1 ảnh cận đứng, 1 ảnh cận ngồi và 1 ảnh cận vùng cơ thể bạn muốn giảm nhất) cho chúng tôi kèm theo bản đăng ký tham gia này</p><p><img src=\'localhost/marketing/uploads/2019/05/14/20190514_1557823698_5cda80d2bfe16.png\' /></p><p><img src=\'localhost/marketing/uploads/2019/05/14/20190514_1557823698_5cda80d2cc87d.png\' /></p><p><img src=\'localhost/marketing/uploads/2019/05/14/20190514_1557823698_5cda80d2d8277.png\' /></p>', NULL, 1, 2, '2019-05-14 15:48:18', '2019-05-14 15:48:18');
INSERT INTO `posts` VALUES (98, NULL, '<p>Cân nặng:FB</p><p>Bụng:10&nbsp;&nbsp;&nbsp;Bắp tay:10</p><p>Eo:10&nbsp;&nbsp;&nbsp;Đùi:10</p><p>Bạn đã từng giảm béo chưa?:Đã từng\n</p><p>Nếu có vì sao bạn lại không sử dụng phương pháp đó nữa ?</p><p>HAT</p><p>Câu chuyện thuyết phục ban giám khảo?:</p><p>cÂU CHUYỆN</p><p>Bạn mong muốn điều gì khi tham gia chương trình?</p><p>CHONG7 TRÌNH</p><p>Nếu được chọn trở thành gương mặt đại diện, bạn sẵn sàng tham gia liệu trình giảm béo Hiulther Lipase trong khoảng 1-2 tháng chứ ?</p><p>Sẵn sàng\n</p><p>Hãy gửi kèm 03 hình ảnh cá nhân mới nhất của bạn (1 ảnh cận đứng, 1 ảnh cận ngồi và 1 ảnh cận vùng cơ thể bạn muốn giảm nhất) cho chúng tôi kèm theo bản đăng ký tham gia này</p><p><img src=\'http://localhost/marketing/uploads/2019/05/14/20190514_1557823831_5cda8157486a6.png\' /></p><p><img src=\'http://localhost/marketing/uploads/2019/05/14/20190514_1557823831_5cda815753f7c.png\' /></p><p><img src=\'http://localhost/marketing/uploads/2019/05/14/20190514_1557823831_5cda815759a1c.png\' /></p>', NULL, 1, 2, '2019-05-14 15:50:31', '2019-05-14 15:50:31');
INSERT INTO `posts` VALUES (99, NULL, '<p>Cân nặng:12,23</p><p>Bụng:10&nbsp;&nbsp;&nbsp;Bắp tay:100</p><p>Eo:10&nbsp;&nbsp;&nbsp;Đùi:100</p><p>Bạn đã từng giảm béo chưa?:Đã từng\n</p><p>Nếu có vì sao bạn lại không sử dụng phương pháp đó nữa ?</p><p>phuong pháp</p><p>Câu chuyện thuyết phục ban giám khảo?:</p><p>câu chuyện thành công</p><p>Bạn mong muốn điều gì khi tham gia chương trình?</p><p>tham gia chương trình</p><p>Nếu được chọn trở thành gương mặt đại diện, bạn sẵn sàng tham gia liệu trình giảm béo Hiulther Lipase trong khoảng 1-2 tháng chứ ?</p><p>Sẵn sàng\n</p><p>03 hình ảnh cá nhân mới nhất (1 ảnh cận đứng, 1 ảnh cận ngồi và 1 ảnh cận vùng cơ thể bạn muốn giảm nhất)</p><h5>Ảnh cận đứng</h5><p><img src=\'http://localhost/marketing/uploads/2019/05/14/20190514_1557825542_5cda8806bf810.png\' /></p><h5>Ảnh cận ngồi</h5><p><img src=\'http://localhost/marketing/uploads/2019/05/14/20190514_1557825542_5cda8806c8565.png\' /></p><h5>Ảnh cận vùng cơ thể</h5><p><img src=\'http://localhost/marketing/uploads/2019/05/14/20190514_1557825542_5cda8806d0a1e.png\' /></p>', NULL, 1, 2, '2019-05-14 16:19:02', '2019-05-14 16:19:02');
INSERT INTO `posts` VALUES (100, NULL, '<p>Cân nặng:12,23</p><p>Bụng:10&nbsp;&nbsp;&nbsp;Bắp tay:10</p><p>Eo:10&nbsp;&nbsp;&nbsp;Đùi:10</p><p>Bạn đã từng giảm béo chưa?:Đã từng\n</p><p>Nếu có vì sao bạn lại không sử dụng phương pháp đó nữa ?</p><p>Phương pháp</p><p>Câu chuyện thuyết phục ban giám khảo?:</p><p>Câu chuyện giám khảo</p><p>Bạn mong muốn điều gì khi tham gia chương trình?</p><p>Chương trình</p><p>Nếu được chọn trở thành gương mặt đại diện, bạn sẵn sàng tham gia liệu trình giảm béo Hiulther Lipase trong khoảng 1-2 tháng chứ ?</p><p>Sẵn sàng\n</p><p>03 hình ảnh cá nhân mới nhất (1 ảnh cận đứng, 1 ảnh cận ngồi và 1 ảnh cận vùng cơ thể bạn muốn giảm nhất)</p><h5>Ảnh cận đứng</h5><p><img src=\'http://localhost/marketing/uploads/2019/05/14/20190514_1557825884_5cda895ccb1e5.png\' /></p><h5>Ảnh cận ngồi</h5><p><img src=\'http://localhost/marketing/uploads/2019/05/14/20190514_1557825884_5cda895cee923.png\' /></p><h5>Ảnh cận vùng cơ thể</h5><p><img src=\'http://localhost/marketing/uploads/2019/05/14/20190514_1557825885_5cda895d06bd7.png\' /></p>', NULL, 1, 2, '2019-05-14 16:24:45', '2019-05-14 16:24:45');
INSERT INTO `posts` VALUES (101, NULL, '<p>Cân nặng:120</p><p>Bụng:10&nbsp;&nbsp;&nbsp;Bắp tay:10</p><p>Eo:01&nbsp;&nbsp;&nbsp;Đùi:01</p><p>Bạn đã từng giảm béo chưa?:Chưa từng\n</p><p>Nếu có vì sao bạn lại không sử dụng phương pháp đó nữa ?</p><p>chuaf</p><p>Câu chuyện thuyết phục ban giám khảo?:</p><p>kklkol</p><p>Bạn mong muốn điều gì khi tham gia chương trình?</p><p>thrhr</p><p>Nếu được chọn trở thành gương mặt đại diện, bạn sẵn sàng tham gia liệu trình giảm béo Hiulther Lipase trong khoảng 1-2 tháng chứ ?</p><p>Sẵn sàng\n</p><p>03 hình ảnh cá nhân mới nhất (1 ảnh cận đứng, 1 ảnh cận ngồi và 1 ảnh cận vùng cơ thể bạn muốn giảm nhất)</p><h5>Ảnh cận đứng</h5><p><img src=\'http://localhost/marketing/uploads/2019/05/14/20190514_1557826194_5cda8a92337be.png\' /></p><h5>Ảnh cận ngồi</h5><p><img src=\'http://localhost/marketing/uploads/2019/05/14/20190514_1557826194_5cda8a923eaa3.png\' /></p><h5>Ảnh cận vùng cơ thể</h5><p><img src=\'http://localhost/marketing/uploads/2019/05/14/20190514_1557826194_5cda8a924697b.png\' /></p>', NULL, 1, 2, '2019-05-14 16:29:54', '2019-05-14 16:29:54');

-- ----------------------------
-- Table structure for products
-- ----------------------------
DROP TABLE IF EXISTS `products`;
CREATE TABLE `products`  (
  `idproduct` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `discription` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idtypeproduct` int(11) NOT NULL,
  `idcategory` int(11) NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`idproduct`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for profile
-- ----------------------------
DROP TABLE IF EXISTS `profile`;
CREATE TABLE `profile`  (
  `idprofile` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `iduser` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `firstname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `middlename` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `lastname` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `birthday` datetime(0) NULL DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `sex` int(2) NULL DEFAULT NULL,
  `mobile` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `about` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `facebook` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `zalo` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `url_avatar` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `created_at` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0),
  PRIMARY KEY (`idprofile`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of profile
-- ----------------------------
INSERT INTO `profile` VALUES (1, '2', 'Hậu', 'Tấn', 'Dương', '1980-09-26 00:00:00', 'Ninh thuận', 1, '0967655819', 'about', 'facebook', 'zalo', 'uploads/2019/05/13/20190513_1557709794_5cd8c3e285e49.png', '2019-05-05 21:02:41', '2019-05-13 08:09:54');
INSERT INTO `profile` VALUES (6, '15', 'hatazu', 'juong', 'zu', '1988-02-02 00:00:00', 'ninh thuan', 0, '0125656556', '', '', '', 'uploads/2019/05/11/20190511_1557541962_5cd6344a2c218.png', '2019-05-08 22:13:47', '2019-05-11 09:32:42');

-- ----------------------------
-- Table structure for roles
-- ----------------------------
DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles`  (
  `idrole` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`idrole`) USING BTREE,
  UNIQUE INDEX `roles_name_unique`(`name`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 2 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of roles
-- ----------------------------
INSERT INTO `roles` VALUES (1, 'administrator', 'Quản trị', '2019-04-13 08:29:22', '2019-04-13 08:30:50');

-- ----------------------------
-- Table structure for status_types
-- ----------------------------
DROP TABLE IF EXISTS `status_types`;
CREATE TABLE `status_types`  (
  `id_status_type` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name_status_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idparent` int(11) NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id_status_type`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of status_types
-- ----------------------------
INSERT INTO `status_types` VALUES (1, 'request', NULL, '2019-03-02 09:22:20', '2019-03-02 09:22:20');
INSERT INTO `status_types` VALUES (2, 'finish', NULL, '2019-04-17 11:41:57', '2019-04-17 11:41:57');

-- ----------------------------
-- Table structure for sv_campaigns
-- ----------------------------
DROP TABLE IF EXISTS `sv_campaigns`;
CREATE TABLE `sv_campaigns`  (
  `idcampaign` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `begin_at` datetime(0) NOT NULL,
  `end_at` datetime(0) NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`idcampaign`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for sv_customers
-- ----------------------------
DROP TABLE IF EXISTS `sv_customers`;
CREATE TABLE `sv_customers`  (
  `idcustomer` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `firstname` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `lastname` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `birthday` datetime(0) NULL DEFAULT NULL,
  `mobile` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `address` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `job` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `facebook` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `note` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `created_at` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP(0),
  `updated_at` timestamp(0) NOT NULL,
  PRIMARY KEY (`idcustomer`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 48 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of sv_customers
-- ----------------------------
INSERT INTO `sv_customers` VALUES (26, 'tu van', NULL, 'hatazu@gmail.com', NULL, '0967655819', 'Bình Dương', NULL, NULL, NULL, '2019-04-29 10:45:50', '2019-04-29 10:45:50');
INSERT INTO `sv_customers` VALUES (27, 'dang ky khuyen mai', NULL, 'admin@mgkgroup.vn', NULL, '0235565656', 'Bình Dương', NULL, NULL, NULL, '2019-04-29 10:45:50', '2019-04-29 10:45:50');
INSERT INTO `sv_customers` VALUES (28, 'hatazu', NULL, 'hatazu@gmail.com', NULL, '055656650', 'abc', NULL, NULL, NULL, '2019-04-29 10:45:50', '2019-04-29 10:45:50');
INSERT INTO `sv_customers` VALUES (29, 'test consultant', NULL, 'hatazu@gmail.com', NULL, '01011212112', 'Bình Dương', NULL, NULL, NULL, '2019-04-29 10:45:50', '2019-04-29 10:45:50');
INSERT INTO `sv_customers` VALUES (30, 'tan hau', NULL, 'hatazu@gmail.com', NULL, '025565656', 'binh duong', NULL, NULL, NULL, '2019-04-29 10:45:50', '2019-04-29 10:45:50');
INSERT INTO `sv_customers` VALUES (31, 'test nhanh khuyến mãi', NULL, 'hatazu@gmail.com', NULL, '02356556656', 'Bình Dương', NULL, NULL, NULL, '2019-04-29 10:45:50', '2019-04-29 10:45:50');
INSERT INTO `sv_customers` VALUES (32, 'khuyen mai', NULL, 'hatazu@gmail.com', NULL, '02565565666', 'Bình Dương', NULL, NULL, NULL, '2019-04-29 10:45:50', '2019-04-29 10:45:50');
INSERT INTO `sv_customers` VALUES (33, 'test khuyen mãi', NULL, 'admin@mgkgroup.vn', NULL, '01561212122', 'Bình Dương', NULL, NULL, NULL, '2019-04-29 10:45:50', '2019-04-29 10:45:50');
INSERT INTO `sv_customers` VALUES (34, 'khuyen mai uu đãi', NULL, 'hatazu@gmail.com', NULL, '066621221', 'Bình Dương', NULL, NULL, NULL, '2019-04-29 10:45:50', '2019-04-29 10:45:50');
INSERT INTO `sv_customers` VALUES (35, 'test post no receive', NULL, 'hatazu@gmail.com', NULL, '01556565666', 'Bình Dương', NULL, NULL, NULL, '2019-04-29 10:45:50', '2019-04-29 10:45:50');
INSERT INTO `sv_customers` VALUES (36, 'khuyen mãi no receive', NULL, 'admin@mgkgroup.vn', NULL, '02565656556', 'Sài Gòn', NULL, NULL, NULL, '2019-04-29 10:45:50', '2019-04-29 10:45:50');
INSERT INTO `sv_customers` VALUES (37, 'test register more', NULL, 'admin@mgkgroup.vn', NULL, '0556556566', 'Đồng Nai', NULL, NULL, NULL, '2019-04-29 10:45:50', '2019-04-29 10:45:50');
INSERT INTO `sv_customers` VALUES (38, 'test again 2019', NULL, 'hatazu@gmail.com', NULL, '0165656566', 'Bình Dương', NULL, NULL, NULL, '2019-05-13 15:15:16', '0000-00-00 00:00:00');
INSERT INTO `sv_customers` VALUES (39, 'test thu thach 45 ngay', NULL, 'cskh1@mgkgroup.vn', NULL, '01565565656', 'Bình Dương', NULL, NULL, NULL, '2019-05-13 15:31:49', '0000-00-00 00:00:00');
INSERT INTO `sv_customers` VALUES (40, 'duong tan hau', NULL, 'hatazu@gmail.com', NULL, '0256565656', 'thu duc', NULL, NULL, NULL, '2019-05-14 14:36:40', '0000-00-00 00:00:00');
INSERT INTO `sv_customers` VALUES (41, 'khao sat', NULL, 'hatazu@gmail.com', NULL, '02656565656', 'thu duc', NULL, NULL, NULL, '2019-05-14 15:01:06', '0000-00-00 00:00:00');
INSERT INTO `sv_customers` VALUES (42, 'duong tan hau', NULL, 'hatazu@gmail.com', NULL, '0556565654', 'fb', NULL, NULL, NULL, '2019-05-14 15:23:35', '0000-00-00 00:00:00');
INSERT INTO `sv_customers` VALUES (43, 'test khảo sát', NULL, 'hatazu@gmail.com', NULL, '02665656', 'thu duc', NULL, NULL, NULL, '2019-05-14 15:46:13', '0000-00-00 00:00:00');
INSERT INTO `sv_customers` VALUES (44, 'test khảo sát', NULL, 'test@gmail.com', NULL, '026565656', 'thu duc', NULL, NULL, NULL, '2019-05-14 15:48:18', '0000-00-00 00:00:00');
INSERT INTO `sv_customers` VALUES (45, 'thử sức', NULL, 'hatazu@gmail.com', NULL, '0556565656', 'fb', NULL, NULL, NULL, '2019-05-14 15:50:31', '0000-00-00 00:00:00');
INSERT INTO `sv_customers` VALUES (46, 'test birthday', NULL, 'facebook@mgkgroup.vn', '1985-01-20 00:00:00', '0265656556', 'binh thạnh', 'IT', 'facebook/fb', NULL, '2019-05-14 16:24:45', '0000-00-00 00:00:00');
INSERT INTO `sv_customers` VALUES (47, 'pánh hẹ', NULL, 'hatz@gmail,coim', '2011-12-20 00:00:00', '0322555', 'ggh', 'uiu', 'ghg', NULL, '2019-05-14 16:29:54', '0000-00-00 00:00:00');

-- ----------------------------
-- Table structure for sv_post_types
-- ----------------------------
DROP TABLE IF EXISTS `sv_post_types`;
CREATE TABLE `sv_post_types`  (
  `id_post_type` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id_post_type`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for sv_posts
-- ----------------------------
DROP TABLE IF EXISTS `sv_posts`;
CREATE TABLE `sv_posts`  (
  `id_svpost` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `idcategory` int(11) NULL DEFAULT NULL,
  `title` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `body` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `url` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `id_post_type` int(11) NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id_svpost`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for sv_receives
-- ----------------------------
DROP TABLE IF EXISTS `sv_receives`;
CREATE TABLE `sv_receives`  (
  `idsv_receive` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `idcustomer` bigint(20) NOT NULL,
  `idsv_post` bigint(20) NOT NULL,
  `result` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `idcampaign` int(11) NOT NULL,
  `ip_address` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `mac_address` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`idsv_receive`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for sv_sends
-- ----------------------------
DROP TABLE IF EXISTS `sv_sends`;
CREATE TABLE `sv_sends`  (
  `idsv_send` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `idcustomer` bigint(20) NOT NULL,
  `idsv_post` bigint(20) NOT NULL,
  `id_user` bigint(20) NOT NULL,
  `idcampaign` int(11) NOT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`idsv_send`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp(0) NULL DEFAULT NULL,
  `password` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `created_at` timestamp(0) NULL DEFAULT NULL,
  `updated_at` timestamp(0) NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `users_email_unique`(`email`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 16 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES (2, 'admin', 'admin@mgkgroup.vn', NULL, '$2y$10$R842bgbIfo7Be2KyLiIxquIBgVf8e/vr0.i0D9NcO56CLekdnclEK', 'xq5yJC3xW8doTo0wnPZa6mXaBIrnDrgcjtgxGQxd92dMitaxdmbcHDcKK6nU', '2019-02-27 10:14:15', '2019-05-10 13:51:03');
INSERT INTO `users` VALUES (15, 'cskh1@mgkgroup.vn', 'cskh1@mgkgroup.vn', NULL, '$2y$10$tLkkIvZrXHlhgKxUCc0DoObdsdJ.Hglai8Sc1HaPi/hb/DPRzY2zS', 'hjPhKivYKcHQEFUanaB6jr5vePYDgjvrFBUGTbKX9KzEFOcIKYcr9iob4dAP', '2019-05-08 22:13:47', '2019-05-10 13:59:20');

-- ----------------------------
-- Procedure structure for activity_interactive
-- ----------------------------
DROP PROCEDURE IF EXISTS `activity_interactive`;
delimiter ;;
CREATE PROCEDURE `activity_interactive`(in _idimport int(11))
BEGIN
  DECLARE _parent_idpost_exp int;
  set _parent_idpost_exp = (select idpost from impposts where idimppost = _idimport);
	select p.body,p.id_post_type,expp.id_status_type,expp.idemployee,expp.created_at from (select exp.* from expposts as exp where exp.parent_idpost_exp = _parent_idpost_exp) as expp join posts as p on expp.idpost = p.idpost;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for CreateProfileProcedure
-- ----------------------------
DROP PROCEDURE IF EXISTS `CreateProfileProcedure`;
delimiter ;;
CREATE PROCEDURE `CreateProfileProcedure`(in _iduser int,in _firstname varchar(255),in _middlename varchar(255),in _lastname varchar(255),in _address varchar(255),in _mobile varchar(255),in _about varchar(255),in _facebook varchar(255),in _zalo varchar(255),in _url_avatar varchar(255))
BEGIN
                insert into profile(iduser,firstname,middlename,lastname,address,mobile,about,facebook ,zalo,url_avatar) values (_iduser,_firstname,_middlename,_lastname,_address,_mobile,_about,_facebook ,_zalo,_url_avatar);
            SELECT LAST_INSERT_ID() as idprofile;
						END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for CreatPostApiProcedure
-- ----------------------------
DROP PROCEDURE IF EXISTS `CreatPostApiProcedure`;
delimiter ;;
CREATE PROCEDURE `CreatPostApiProcedure`(IN _namecat VARCHAR(255), IN _body text, IN _nametype VARCHAR(255), IN _idfile INT(11), IN _firstname VARCHAR(255), IN _mobile VARCHAR(255), IN _email VARCHAR(255), IN _address VARCHAR(255), IN _name_status_type VARCHAR(250), IN _birthday VARCHAR(255), IN _job VARCHAR(255), IN _facebook VARCHAR(255))
BEGIN
            DECLARE _idcategory INT;
            DECLARE _idposttype INT;
            DECLARE _idpost INT;
            DECLARE _idcattype INT;
            DECLARE _catnametype VARCHAR(255);
            DECLARE _hastype VARCHAR(255);
            DECLARE _idcustomer INT;
            DECLARE _percent_process INT;
            DECLARE _id_status_type INT;
            DECLARE _id_imppost INT;
            SET _percent_process = 0;
            SET _id_status_type = (SELECT id_status_type FROM status_types WHERE name_status_type = _name_status_type);
            SET _catnametype = "website";
            SET _idcattype = (SELECT idcattype FROM category_types WHERE catnametype=_catnametype); 
            SET _idposttype = (SELECT idposttype FROM post_types WHERE nametype = _nametype);
            SET _hastype = "image";
            IF EXISTS(SELECT _idcustomer FROM sv_customers WHERE mobile = _mobile LIMIT 1) THEN
                BEGIN
                SET _idcustomer = (SELECT idcustomer FROM sv_customers WHERE mobile = _mobile LIMIT 1);
                END;
            ELSE
                BEGIN
                INSERT INTO sv_customers(firstname, email, mobile, address, birthday, job, facebook) VALUES(_firstname,_email,_mobile,_address, _birthday, _job, _facebook);
                SET _idcustomer = LAST_INSERT_ID();
                END;
            END IF;
            IF EXISTS(SELECT idcategory FROM categories WHERE namecat = _namecat LIMIT 1) THEN
                BEGIN
                SET _idcategory = (SELECT idcategory FROM categories WHERE namecat = _namecat LIMIT 1);
                END;
            ELSE
                BEGIN
                INSERT INTO categories(namecat,idcattype,idparent) VALUES(_namecat,_idcattype,NULL); 
                SET _idcategory = LAST_INSERT_ID();
                END;
            END IF;
            INSERT INTO posts(body,id_post_type,idcategory) VALUES(_body,_idposttype,_idcategory);
            SET _idpost = LAST_INSERT_ID();
            INSERT INTO post_has_files (idpost,hastype,idfile) VALUES(_idpost,_hastype,_idfile);
            INSERT INTO impposts(idpost,id_status_type,percent_process,iduser_imp,address_reg) VALUES(_idpost,_id_status_type,_percent_process,_idcustomer,_address);
            SET _id_imppost = LAST_INSERT_ID();
            SELECT _id_imppost;
        END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for customer_interactive
-- ----------------------------
DROP PROCEDURE IF EXISTS `customer_interactive`;
delimiter ;;
CREATE PROCEDURE `customer_interactive`(in _parent_idpost_exp int,in _body text,in _id_post_type int, in _id_status_type int, in _idemployee int)
BEGIN
	DECLARE	_idpost INT;
	INSERT INTO posts(body,id_post_type) VALUES(_body,_id_post_type);
        SET _idpost = LAST_INSERT_ID();
        INSERT INTO expposts(idpost,id_status_type,idemployee,parent_idpost_exp) VALUES(_idpost,_id_status_type,_idemployee,_parent_idpost_exp);
	select LAST_INSERT_ID() as id_exppost;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for DeleteUserProcedure
-- ----------------------------
DROP PROCEDURE IF EXISTS `DeleteUserProcedure`;
delimiter ;;
CREATE PROCEDURE `DeleteUserProcedure`(in _iduser int)
BEGIN
                delete from users where id=_iduser;
            END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for DetailInteractive
-- ----------------------------
DROP PROCEDURE IF EXISTS `DetailInteractive`;
delimiter ;;
CREATE PROCEDURE `DetailInteractive`(in _idimport int)
BEGIN
	select post_imp.*, cus.* from (select p.idpost, p.body, imp.iduser_imp from (select * from impposts where idimppost = _idimport) as imp left join posts as p on imp.idpost=p.idpost) as post_imp join
	 sv_customers as cus on cus.idcustomer = post_imp.iduser_imp;
    END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for Getparentidprocedure
-- ----------------------------
DROP PROCEDURE IF EXISTS `Getparentidprocedure`;
delimiter ;;
CREATE PROCEDURE `Getparentidprocedure`(IN id_post int(11))
BEGIN
                  DECLARE A INT;
                  DECLARE XYZ Varchar(50);
                  SET A = 1;
                  SET XYZ = "";
                  WHILE A <=10 DO
                  SET XYZ = CONCAT(XYZ,A,",");
                  SET A = A + 1;
                  END WHILE;
                  SELECT XYZ;
            END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for ImppermbyidProcedure
-- ----------------------------
DROP PROCEDURE IF EXISTS `ImppermbyidProcedure`;
delimiter ;;
CREATE PROCEDURE `ImppermbyidProcedure`(IN idimpperm int(11))
BEGIN
                SELECT imp.idimp_perm, imp.idperm, p.name as nameperm,p.description as desperm, imp.idrole, r.name as namerole,r.description as desrole,u.name as nameuser FROM (select * from imp_perms where idimp_perm = idimpperm) as imp left join permissions as p ON imp.idperm = p.idperm LEFT join roles as r on imp.idrole = r.idrole LEFT join users as u ON imp.iduserimp = u.id;
            END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for InsertFilesProcedure
-- ----------------------------
DROP PROCEDURE IF EXISTS `InsertFilesProcedure`;
delimiter ;;
CREATE PROCEDURE `InsertFilesProcedure`(IN _urlfile varchar(255),IN _name_origin varchar(255),IN _namefile varchar(255),IN _typefile varchar(255))
BEGIN
                INSERT INTO files(urlfile,name_origin,namefile, typefile) VALUES (_urlfile,_name_origin, _namefile, _typefile);
                SELECT LAST_INSERT_ID() as idfile;
            END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for InsertPostProcedure
-- ----------------------------
DROP PROCEDURE IF EXISTS `InsertPostProcedure`;
delimiter ;;
CREATE PROCEDURE `InsertPostProcedure`(IN _title varchar(255), IN _body text, IN _slug varchar(255), IN _id_post_type int(11), IN _idcategory int(11), IN _id_status_type int(11), IN _processing DECIMAL(6,2), IN _iduser_imp int(11))
BEGIN
                INSERT INTO posts(title, body, slug, id_post_type, idcategory) VALUES ( _title, _body, _slug, _id_post_type, _idcategory);
                    SET @_idpost = LAST_INSERT_ID();
                    INSERT INTO impposts(idpost, id_status_type, processing, iduser_imp) VALUES ( @_idpost, _id_status_type, _processing, _iduser_imp);
                    select @_idpost as outidpost;
            END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for ListAllCatByTypeProcedure
-- ----------------------------
DROP PROCEDURE IF EXISTS `ListAllCatByTypeProcedure`;
delimiter ;;
CREATE PROCEDURE `ListAllCatByTypeProcedure`(IN _namecattype VARCHAR(255))
BEGIN
        DECLARE _idcattype INT;
        SET _idcattype = (SELECT idcattype FROM category_types WHERE catnametype = _namecattype);
        IF _idcattype > 0 THEN
        BEGIN
           SELECT * FROM categories WHERE idcattype = _idcattype;
        END; 
        ELSE
        BEGIN
           SELECT * FROM categories;    
        END;
        END IF;
        END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for ListAllCategoryProcedure
-- ----------------------------
DROP PROCEDURE IF EXISTS `ListAllCategoryProcedure`;
delimiter ;;
CREATE PROCEDURE `ListAllCategoryProcedure`()
BEGIN
            SELECT idcategory,namecat,idparent FROM categories;
            END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for ListCategoryByTypeProcedure
-- ----------------------------
DROP PROCEDURE IF EXISTS `ListCategoryByTypeProcedure`;
delimiter ;;
CREATE PROCEDURE `ListCategoryByTypeProcedure`()
BEGIN
	SELECT idcategory, namecat from categories;
    END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for ListCategoryProcedure
-- ----------------------------
DROP PROCEDURE IF EXISTS `ListCategoryProcedure`;
delimiter ;;
CREATE PROCEDURE `ListCategoryProcedure`()
BEGIN
                SELECT c1.idcategory, c1.namecat, c1.idcattype, (select catnametype from category_types where idcattype=c1.idcattype) as catnametype, c2.namecat as parent from categories as c1 left Join categories as c2 on c1.idparent = c2.idcategory;
            END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for ListcatparentProcedure
-- ----------------------------
DROP PROCEDURE IF EXISTS `ListcatparentProcedure`;
delimiter ;;
CREATE PROCEDURE `ListcatparentProcedure`()
BEGIN
                SELECT c1.idcategory, c1.namecat from categories as c1 where c1.idparent is null;
            END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for ListCustomerRegister
-- ----------------------------
DROP PROCEDURE IF EXISTS `ListCustomerRegister`;
delimiter ;;
CREATE PROCEDURE `ListCustomerRegister`(IN _start_date VARCHAR(255),IN _end_date VARCHAR(255), IN _idcategory INT(11), IN _id_post_type INT(11), IN _id_status_type INT(11), in _sel_receive int(11))
BEGIN
        DECLARE _now VARCHAR(255);
        DECLARE _str_start VARCHAR(255);
        DECLARE _now_time VARCHAR(255);
        SET _now_time = NOW();
        IF ( _start_date IS NULL OR _start_date ="") THEN
        BEGIN
            SET _now = DATE(_now_time);
            SET _str_start = CONCAT(_now," 00:00:00");
            SET _start_date = STR_TO_DATE(_str_start,"%Y-%m-%d %H:%i:%s");          
        END;
        END IF;
        IF ( _end_date IS NULL OR _end_date = "") THEN SET _end_date = _now_time;       
        END IF;
        if ( _sel_receive = 0 AND _id_post_type = 0) then
		begin
		    SELECT user_reg.idimppost,user_reg.idpost,user_reg.created_at,cus.mobile,cus.firstname,cus.email,user_reg.body,user_reg.address_reg FROM (SELECT imp.created_at,imp.idpost,imp.idimppost,imp.iduser_imp,po.body,imp.address_reg FROM (SELECT im.* FROM (SELECT * FROM impposts WHERE created_at >= _start_date AND  created_at < _end_date) AS im WHERE im.id_status_type = _id_status_type) AS imp JOIN
		    (SELECT pt.* FROM (SELECT p.* FROM (SELECT idpost,body,id_post_type,idcategory FROM posts WHERE created_at >= _start_date AND created_at < _end_date) AS p WHERE p.idcategory=_idcategory) AS pt WHERE pt.id_post_type = '1' OR pt.id_post_type = '2') AS po ON imp.idpost=po.idpost) AS user_reg JOIN
		    sv_customers AS cus ON user_reg.iduser_imp = cus.idcustomer;
		end;
	elseif ( _sel_receive = 1 AND _id_post_type = 0) then
		BEGIN
		    select user_join.idimppost,user_join.idpost,user_join.created_at,cus.mobile,cus.firstname,cus.email,user_join.body,user_join.address_reg  from (SELECT user_reg.idimppost,user_reg.idpost,user_reg.iduser_imp,user_reg.created_at,user_reg.body,user_reg.address_reg FROM (SELECT imp.created_at,imp.idpost,imp.idimppost,imp.iduser_imp,po.body,imp.address_reg FROM (SELECT im.* FROM (SELECT * FROM impposts WHERE created_at >= _start_date AND  created_at < _end_date) AS im WHERE im.id_status_type='1') AS imp JOIN
		    (SELECT pt.* FROM (SELECT p.* FROM (SELECT idpost,body,id_post_type,idcategory FROM posts WHERE created_at >= _start_date AND created_at < _end_date) AS p WHERE p.idcategory=_idcategory) AS pt WHERE pt.id_post_type = '1' OR pt.id_post_type = '2') AS po ON imp.idpost = po.idpost) AS user_reg LEFT JOIN expposts AS expp ON user_reg.idpost = expp.parent_idpost_exp WHERE expp.parent_idpost_exp IS NULL) as user_join join sv_customers as cus on cus.idcustomer = user_join.iduser_imp;
		end;
	ELSEIF ( _sel_receive = 2 AND _id_post_type = 0 ) then
		BEGIN
		    SELECT user_join.idimppost,user_join.idpost,user_join.created_at,cus.mobile,cus.firstname,cus.email,user_join.body,user_join.address_reg  FROM (SELECT user_reg.idimppost,user_reg.idpost,user_reg.iduser_imp,user_reg.created_at,user_reg.body,user_reg.address_reg FROM (SELECT imp.created_at,imp.idpost,imp.idimppost,imp.iduser_imp,po.body,imp.address_reg FROM (SELECT im.* FROM (SELECT * FROM impposts WHERE created_at >= _start_date AND  created_at < _end_date) AS im WHERE im.id_status_type='1') AS imp JOIN
		    (SELECT pt.* FROM (SELECT p.* FROM (SELECT idpost,body,id_post_type,idcategory FROM posts WHERE created_at >= _start_date AND created_at < _end_date) AS p WHERE p.idcategory=_idcategory) AS pt WHERE pt.id_post_type = '1' OR pt.id_post_type = '2') AS po ON imp.idpost = po.idpost) AS user_reg right JOIN ( select * from expposts GROUP BY parent_idpost_exp ) AS expp ON user_reg.idpost = expp.parent_idpost_exp) AS user_join JOIN sv_customers AS cus ON cus.idcustomer = user_join.iduser_imp;
		END;
	elseIF ( _sel_receive = 0 AND _id_post_type > 0) THEN
		BEGIN
		    SELECT user_reg.idimppost,user_reg.idpost,user_reg.created_at,cus.mobile,cus.firstname,cus.email,user_reg.body,user_reg.address_reg FROM (SELECT imp.created_at,imp.idpost,imp.idimppost,imp.iduser_imp,po.body,imp.address_reg FROM (SELECT im.* FROM (SELECT * FROM impposts WHERE created_at >= _start_date AND  created_at < _end_date) AS im WHERE im.id_status_type = _id_status_type) AS imp JOIN
		    (SELECT pt.* FROM (SELECT p.* FROM (SELECT idpost,body,id_post_type,idcategory FROM posts WHERE created_at >= _start_date AND created_at < _end_date) AS p WHERE p.idcategory=_idcategory) AS pt WHERE pt.id_post_type = _id_post_type) AS po ON imp.idpost=po.idpost) AS user_reg JOIN
		    sv_customers AS cus ON user_reg.iduser_imp = cus.idcustomer;
		END;
	ELSEIF ( _sel_receive = 1 AND _id_post_type > 0) THEN
		BEGIN
		    SELECT user_join.idimppost,user_join.idpost,user_join.created_at,cus.mobile,cus.firstname,cus.email,user_join.body,user_join.address_reg  FROM (SELECT user_reg.idimppost,user_reg.idpost,user_reg.iduser_imp,user_reg.created_at,user_reg.body,user_reg.address_reg FROM (SELECT imp.created_at,imp.idpost,imp.idimppost,imp.iduser_imp,po.body,imp.address_reg FROM (SELECT im.* FROM (SELECT * FROM impposts WHERE created_at >= _start_date AND  created_at < _end_date) AS im WHERE im.id_status_type='1') AS imp JOIN
		    (SELECT pt.* FROM (SELECT p.* FROM (SELECT idpost,body,id_post_type,idcategory FROM posts WHERE created_at >= _start_date AND created_at < _end_date) AS p WHERE p.idcategory=_idcategory) AS pt WHERE pt.id_post_type = _id_post_type) AS po ON imp.idpost = po.idpost) AS user_reg LEFT JOIN expposts AS expp ON user_reg.idpost = expp.parent_idpost_exp WHERE expp.parent_idpost_exp IS NULL) AS user_join JOIN sv_customers AS cus ON cus.idcustomer = user_join.iduser_imp;
		END;
	ELSEIF ( _sel_receive = 2 AND _id_post_type > 0 ) THEN
		BEGIN
		    SELECT user_join.idimppost,user_join.idpost,user_join.created_at,cus.mobile,cus.firstname,cus.email,user_join.body,user_join.address_reg  FROM (SELECT user_reg.idimppost,user_reg.idpost,user_reg.iduser_imp,user_reg.created_at,user_reg.body,user_reg.address_reg FROM (SELECT imp.created_at,imp.idpost,imp.idimppost,imp.iduser_imp,po.body,imp.address_reg FROM (SELECT im.* FROM (SELECT * FROM impposts WHERE created_at >= _start_date AND  created_at < _end_date) AS im WHERE im.id_status_type='1') AS imp JOIN
		    (SELECT pt.* FROM (SELECT p.* FROM (SELECT idpost,body,id_post_type,idcategory FROM posts WHERE created_at >= _start_date AND created_at < _end_date) AS p WHERE p.idcategory=_idcategory) AS pt WHERE pt.id_post_type = _id_post_type) AS po ON imp.idpost = po.idpost) AS user_reg RIGHT JOIN expposts AS expp ON user_reg.idpost = expp.parent_idpost_exp) AS user_join JOIN sv_customers AS cus ON cus.idcustomer = user_join.iduser_imp;
		END;
        end if;  
        END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for ListDepartmentProcedure
-- ----------------------------
DROP PROCEDURE IF EXISTS `ListDepartmentProcedure`;
delimiter ;;
CREATE PROCEDURE `ListDepartmentProcedure`()
BEGIN
                SELECT c1.iddepart, c1.namedepart, c2.namedepart as parent from departments as c1 left Join departments as c2 on c1.idparent = c2.iddepart;
            END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for ListDepartParentProcedure
-- ----------------------------
DROP PROCEDURE IF EXISTS `ListDepartParentProcedure`;
delimiter ;;
CREATE PROCEDURE `ListDepartParentProcedure`()
BEGIN
                SELECT c1.iddepart, c1.namedepart from departments as c1 where c1.idparent is null;
            END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for ListgrantbyidProcedure
-- ----------------------------
DROP PROCEDURE IF EXISTS `ListgrantbyidProcedure`;
delimiter ;;
CREATE PROCEDURE `ListgrantbyidProcedure`(IN id_grant int(11))
BEGIN
                SELECT r.idrole, r.name as namerole, g.to_iduser,(select name from users where id = g.to_iduser) as touser, g.by_iduser,(select name from users where id = g.by_iduser) as byuser FROM (select * from grants where idgrant = id_grant) as g LEFT join roles as r on g.idrole = r.idrole;
            END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for ListgrantProcedure
-- ----------------------------
DROP PROCEDURE IF EXISTS `ListgrantProcedure`;
delimiter ;;
CREATE PROCEDURE `ListgrantProcedure`()
BEGIN
                SELECT g.idgrant, r.idrole, r.name as namerole, (select name from users where id = g.to_iduser) as touser, (select name from users where id=g.by_iduser) as byuser from grants as g LEFT join roles as r on g.idrole = r.idrole;
            END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for ListImppermProcedure
-- ----------------------------
DROP PROCEDURE IF EXISTS `ListImppermProcedure`;
delimiter ;;
CREATE PROCEDURE `ListImppermProcedure`()
BEGIN
                SELECT imp.idimp_perm, p.name as nameperm, r.name as namerole, u.name as nameuser FROM imp_perms as imp left join permissions as p ON imp.idperm = p.idperm LEFT join roles as r on imp.idrole = r.idrole LEFT join users as u ON imp.iduserimp = u.id;
            END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for ListpostProcedure
-- ----------------------------
DROP PROCEDURE IF EXISTS `ListpostProcedure`;
delimiter ;;
CREATE PROCEDURE `ListpostProcedure`()
BEGIN
                SELECT * from posts;
            END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for ListPostTypeByIdcatProcedure
-- ----------------------------
DROP PROCEDURE IF EXISTS `ListPostTypeByIdcatProcedure`;
delimiter ;;
CREATE PROCEDURE `ListPostTypeByIdcatProcedure`(IN _idcat int)
BEGIN
        IF _idcat > 0 THEN
        BEGIN
           SELECT * FROM post_types WHERE idparent = _idcat;
        END; 
        ELSE
        BEGIN
           SELECT * FROM post_types;    
        END;
        END IF;
        END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for ListRoleIdpermProcedure
-- ----------------------------
DROP PROCEDURE IF EXISTS `ListRoleIdpermProcedure`;
delimiter ;;
CREATE PROCEDURE `ListRoleIdpermProcedure`(IN id_perm int(11))
BEGIN
                select r.idrole, r.name, p.idimp_perm, p.idrole as id_role from roles as r LEFT join (select * from imp_perms where idperm=id_perm) as p on r.idrole=p.idrole;
            END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for ListSelEmpDepartProcedure
-- ----------------------------
DROP PROCEDURE IF EXISTS `ListSelEmpDepartProcedure`;
delimiter ;;
CREATE PROCEDURE `ListSelEmpDepartProcedure`(IN _iduser int(11))
BEGIN
                SELECT iddepart_employee, iddepart from depart_employees where iduser=_iduser;
            END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for ListStatusTypeProcedure
-- ----------------------------
DROP PROCEDURE IF EXISTS `ListStatusTypeProcedure`;
delimiter ;;
CREATE PROCEDURE `ListStatusTypeProcedure`(IN _idparent int)
BEGIN
        IF _idparent > 0 THEN
        BEGIN
           SELECT * FROM status_types WHERE idparent = _idparent;
        END; 
        ELSE
        BEGIN
           SELECT * FROM status_types;    
        END;
        END IF;
        END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for ListTypeSelectedProcedure
-- ----------------------------
DROP PROCEDURE IF EXISTS `ListTypeSelectedProcedure`;
delimiter ;;
CREATE PROCEDURE `ListTypeSelectedProcedure`(IN id_post int(11))
BEGIN
                SELECT p.id_post_type as idposttype,(select nametype from post_types WHERE idposttype = p.id_post_type) as nameposttype,p.idcategory,(SELECT name FROM categories WHERE idcategory = p.idcategory) as namecate FROM posts as p WHERE p.idpost=id_post;
            END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for PostByIdProcedure
-- ----------------------------
DROP PROCEDURE IF EXISTS `PostByIdProcedure`;
delimiter ;;
CREATE PROCEDURE `PostByIdProcedure`(IN id_post int(11))
BEGIN
                SELECT p.title,p.body,p.slug,p.id_post_type as idposttype,(select nametype from post_types WHERE idposttype = p.id_post_type) as nameposttype,p.idcategory,(SELECT namecat FROM categories WHERE idcategory = p.idcategory) as namecate FROM posts as p WHERE p.idpost=id_post;
            END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for PostHasFileProcedure
-- ----------------------------
DROP PROCEDURE IF EXISTS `PostHasFileProcedure`;
delimiter ;;
CREATE PROCEDURE `PostHasFileProcedure`(IN _idpost int(11),IN _idfile int(11))
BEGIN
                INSERT INTO post_has_files(idpost,idfile) VALUES (_idpost,_idfile);
                SELECT LAST_INSERT_ID() as idposthasfile;
            END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for SelCategorybyIdProcedure
-- ----------------------------
DROP PROCEDURE IF EXISTS `SelCategorybyIdProcedure`;
delimiter ;;
CREATE PROCEDURE `SelCategorybyIdProcedure`(IN idcat int(11))
BEGIN
                SELECT c1.idcategory, c1.namecat, c1.idcattype, (select catnametype from category_types where idcattype=c1.idcattype) as catnametype, c1.idparent, c2.namecat as parent from (select * from categories where idcategory=idcat) as c1 left Join categories as c2 on c1.idparent = c2.idcategory;
            END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for SelDepartmentByIdProcedure
-- ----------------------------
DROP PROCEDURE IF EXISTS `SelDepartmentByIdProcedure`;
delimiter ;;
CREATE PROCEDURE `SelDepartmentByIdProcedure`(IN _iddepart int(11))
BEGIN
                SELECT c1.iddepart, c1.namedepart, c1.idparent, c2.namedepart as parent from (select * from departments where iddepart=_iddepart) as c1 left Join departments as c2 on c1.idparent = c2.iddepart;
            END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for SelectProfileByIdProcedure
-- ----------------------------
DROP PROCEDURE IF EXISTS `SelectProfileByIdProcedure`;
delimiter ;;
CREATE PROCEDURE `SelectProfileByIdProcedure`(IN `_idprofile` int)
BEGIN
	select * from `profile` WHERE idprofile=_idprofile;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for SelectProfileProcedure
-- ----------------------------
DROP PROCEDURE IF EXISTS `SelectProfileProcedure`;
delimiter ;;
CREATE PROCEDURE `SelectProfileProcedure`(in _iduser int)
BEGIN
                SELECT * from `profile` where iduser=_iduser; 
            END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for SellistcategorybyidProcedure
-- ----------------------------
DROP PROCEDURE IF EXISTS `SellistcategorybyidProcedure`;
delimiter ;;
CREATE PROCEDURE `SellistcategorybyidProcedure`(IN idcat int(11))
BEGIN
                SELECT c1.idcategory, c1.namecat from categories as c1 where c1.idparent = idcat;
            END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for SelListDepartmentByIdProcedure
-- ----------------------------
DROP PROCEDURE IF EXISTS `SelListDepartmentByIdProcedure`;
delimiter ;;
CREATE PROCEDURE `SelListDepartmentByIdProcedure`(IN _iddepart int(11))
BEGIN
                SELECT c1.iddepart, c1.namedepart from departments as c1 where c1.idparent = _iddepart;
            END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for UpdateImppostByIdProcedure
-- ----------------------------
DROP PROCEDURE IF EXISTS `UpdateImppostByIdProcedure`;
delimiter ;;
CREATE PROCEDURE `UpdateImppostByIdProcedure`(IN id_imp_post int(11),IN id_post int(11),IN id_category int(11),IN  id_posttype int(11),IN  id_statustype int(11),IN  id_user_imp int(11))
if (id_imp_post > 0 )  then
                    update impposts set idpost=id_post,idcategory=id_category,id_post_type=id_posttype,id_status_type = id_statustype,iduser_imp = id_user_imp
                    where idimppost = id_imp_post;
                else
                    insert into impposts(idpost,idcategory,id_post_type,id_status_type,iduser_imp) values(id_post,id_category,id_posttype,id_statustype,id_user_imp);
                end if
;;
delimiter ;

-- ----------------------------
-- Procedure structure for UpdateProfileProcedure
-- ----------------------------
DROP PROCEDURE IF EXISTS `UpdateProfileProcedure`;
delimiter ;;
CREATE PROCEDURE `UpdateProfileProcedure`(IN _idprofile int, IN `_firstname` varchar(255),IN `_lastname` varchar(255),IN `_middlename` varchar(255),IN `_sex` int,IN   `_birthday` datetime, IN `_address` varchar(255), IN `_mobile` varchar(255))
BEGIN
	update `profile` set firstname = _firstname, lastname=_lastname, middlename=_middlename, sex=_sex, birthday = _birthday, address=_address, mobile=_mobile where idprofile = _idprofile;
END
;;
delimiter ;

-- ----------------------------
-- Procedure structure for UploadAvatarProcedure
-- ----------------------------
DROP PROCEDURE IF EXISTS `UploadAvatarProcedure`;
delimiter ;;
CREATE PROCEDURE `UploadAvatarProcedure`(in _idprofile int, in _url_avatar varchar(255))
BEGIN
                update `profile` set url_avatar = _url_avatar where idprofile=_idprofile;
            END
;;
delimiter ;

SET FOREIGN_KEY_CHECKS = 1;
